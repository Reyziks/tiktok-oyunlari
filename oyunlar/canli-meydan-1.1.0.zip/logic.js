// Canlı Meydan oyun mantığı. Herkes meydanda kendi karakteriyle görünür; yarışma yok, birlikte enerji toplanır.
// Saf ESM modül: saat ve rastgelelik dışarıdan verilir.
import { readFileSync } from 'node:fs';

const manifest = JSON.parse(readFileSync(new URL('./manifest.json', import.meta.url), 'utf8'));
const DEFAULTS = Object.fromEntries(manifest.settings.map((s) => [s.key, s.default]));

const BUBBLE_MAX = 60;
const TOAST_LIMIT = 4;
// Hediye büyüklüğüne (toplam elmas) göre meydan olayı ve süresi.
const EVENTS = [
  { min: 99, kind: 'star', ms: 10000 },
  { min: 20, kind: 'dance', ms: 8000 },
  { min: 5, kind: 'hearts', ms: 6000 },
  { min: 0, kind: 'flowers', ms: 6000 },
];
const BUILD_STEPS = [0.25, 0.5, 0.75]; // enerji oranı: çeşme, sahne, dönme dolap
const BIG_GIFT = 20; // bu ve üstü büyük hediye duyurulur (99+ yıldız)
const SWAPS_KEPT = 8;
const VOICES_KEPT = 4;
const PEOPLE_MAX = 5000;

function resolveSettings(input = {}) {
  const out = { ...DEFAULTS };
  for (const [key, def] of Object.entries(DEFAULTS)) {
    const v = input[key];
    if (v === undefined || v === null || v === '') continue;
    if (typeof def === 'number') {
      const n = Number(v);
      if (Number.isFinite(n)) out[key] = n;
    } else if (typeof def === 'boolean') {
      out[key] = typeof v === 'boolean' ? v : String(v) !== 'false';
    } else {
      out[key] = String(v);
    }
  }
  return out;
}

export function create(settings, { now = Date.now, random = Math.random } = {}) {
  const cfg = resolveSettings(settings);
  const people = new Map(); // id → kişi
  let seq = 0;
  let energy = 0;
  let built = 0;
  let parties = 0;
  let partyEnd = null;
  let event = null; // { seq, kind, by, byId, until }
  let toasts = [];
  let seats = []; // ekrandaki yerler: kişi id ya da null (en fazla maxVisible)
  let swaps = []; // [{ seq, seat, outId, inId }]
  let voices = []; // [{ seq, cue }] sunucu sesi işaretleri
  let welcomed = false;

  const at = () => now();
  const cue = (name) => {
    voices.push({ seq: ++seq, cue: name });
    if (voices.length > VOICES_KEPT) voices = voices.slice(-VOICES_KEPT);
  };
  const isAfk = (p, t) => p.lastActiveAt <= t - cfg.afkSec * 1000;
  const seated = (id) => seats.includes(id);

  // Boş yer varsa gelen hemen oturur; dolu yerdeki aktif kişi asla atılmaz.
  function seat(p) {
    if (seated(p.id)) return;
    let i = seats.indexOf(null);
    if (i < 0 && seats.length < cfg.maxVisible) i = seats.length;
    if (i >= 0) seats[i] = p.id;
  }

  // AFK olanın yerine, bekleyenlerden en yüksek puanlı gelir ve konumunu devralır.
  function fillSeats(t) {
    for (let i = 0; i < seats.length; i++) {
      const id = seats[i];
      const p = id && people.get(id);
      if (p && !isAfk(p, t)) continue;
      let best = null;
      for (const c of people.values()) {
        if (seated(c.id) || isAfk(c, t)) continue;
        if (!best || c.score > best.score || (c.score === best.score && c.lastActiveAt > best.lastActiveAt)) best = c;
      }
      seats[i] = best ? best.id : null;
      if (best && p) {
        best.x = p.x;
        best.y = p.y;
        swaps.push({ seq: ++seq, seat: i, outId: p.id, inId: best.id });
        if (swaps.length > SWAPS_KEPT) swaps = swaps.slice(-SWAPS_KEPT);
      }
    }
  }

  function prune(t) {
    if (people.size <= PEOPLE_MAX) return;
    const idle = [...people.values()].filter((p) => !seated(p.id) && isAfk(p, t)).sort((a, b) => a.score - b.score);
    for (const p of idle.slice(0, people.size - PEOPLE_MAX)) people.delete(p.id);
  }

  function personOf(user) {
    let p = people.get(user.id);
    if (!p) {
      p = {
        id: user.id,
        nickname: user.nickname || user.uniqueId || user.id,
        avatarUrl: user.avatarUrl || '',
        x: 0.05 + random() * 0.9,
        y: random(),
        bubble: null,
        bubbleSeq: 0,
        bubbleUntil: 0,
        jumpSeq: 0,
        score: 0,
        lastActiveAt: at(),
      };
      people.set(user.id, p);
      if (!welcomed) {
        welcomed = true;
        cue('welcome');
      }
    } else {
      if (user.nickname) p.nickname = user.nickname;
      if (user.avatarUrl) p.avatarUrl = user.avatarUrl;
    }
    p.lastActiveAt = at();
    return p;
  }

  function addEnergy(n, p) {
    if (!(n > 0)) return;
    p.score += n; // ekranda kalma puanı parti sırasında da birikir
    if (partyEnd !== null) return; // parti sırasında enerji birikmez
    energy += n;
    for (let i = BUILD_STEPS.length; i > 0; i--) {
      if (energy >= BUILD_STEPS[i - 1] * cfg.partyEnergy) {
        if (i > built) cue('build_step');
        built = Math.max(built, i);
        break;
      }
    }
    if (energy >= cfg.partyEnergy) {
      energy = 0;
      parties++;
      partyEnd = at() + cfg.partySec * 1000;
      cue('party');
    }
  }

  function toast(text) {
    toasts.push({ id: `t${++seq}`, text });
    if (toasts.length > TOAST_LIMIT) toasts = toasts.slice(-TOAST_LIMIT);
  }

  function onGift(p, g) {
    if (!g || !g.final) return; // seri hediye: puan ve olay seri bitince
    const diamonds = Math.max(0, Number(g.diamonds) || 0) * Math.max(1, Number(g.count) || 1);
    const def = EVENTS.find((e) => diamonds >= e.min);
    event = { seq: ++seq, kind: def.kind, by: p.nickname, byId: p.id, gift: g.name, count: g.count, until: at() + def.ms };
    if (def.kind === 'star') cue('star');
    else if (diamonds >= BIG_GIFT) cue('big_gift');
    addEnergy(diamonds * cfg.diamondEnergy, p);
  }

  function onEvent(evt) {
    if (!evt || !evt.user || !evt.user.id) return;
    const p = personOf(evt.user);
    switch (evt.type) {
      case 'comment': {
        const text = String(evt.comment ?? '').trim().slice(0, BUBBLE_MAX);
        if (text) {
          p.bubble = text;
          p.bubbleSeq = ++seq;
          p.bubbleUntil = at() + cfg.bubbleSec * 1000;
        }
        addEnergy(cfg.commentEnergy, p);
        break;
      }
      case 'like':
        p.jumpSeq++;
        addEnergy(Math.max(0, Number(evt.likeCount) || 0) * cfg.likeEnergy, p);
        break;
      case 'gift':
        onGift(p, evt.gift);
        break;
      case 'follow':
        toast(`${p.nickname} takip etti ⭐`);
        addEnergy(cfg.followEnergy, p);
        break;
      case 'share':
        toast(`${p.nickname} yayını paylaştı 📣`);
        addEnergy(cfg.shareEnergy, p);
        break;
      default:
        break;
    }
    seat(p);
  }

  function tick(nowMs) {
    if (event && nowMs >= event.until) event = null;
    if (partyEnd !== null && nowMs >= partyEnd) partyEnd = null;
    fillSeats(nowMs);
    prune(nowMs);
  }

  function getState() {
    const t = at();
    const liveEvent = event && t < event.until ? event : null;
    const starId = liveEvent?.kind === 'star' ? liveEvent.byId : null;
    const visible = seats.filter(Boolean).map((id) => people.get(id)).filter(Boolean);
    if (starId && !visible.some((p) => p.id === starId) && people.has(starId)) {
      if (visible.length >= cfg.maxVisible) visible[visible.length - 1] = people.get(starId);
      else visible.push(people.get(starId));
    }
    let total = 0;
    for (const p of people.values()) if (!isAfk(p, t)) total++;
    return {
      total,
      people: visible.map((p) => ({
        id: p.id,
        nickname: p.nickname,
        avatarUrl: p.avatarUrl,
        x: p.x,
        y: p.y,
        bubble: t < p.bubbleUntil ? p.bubble : null,
        bubbleSeq: p.bubbleSeq,
        jumpSeq: p.jumpSeq,
        star: p.id === starId,
      })),
      energy,
      partyEnergy: cfg.partyEnergy,
      built,
      party: partyEnd !== null && t < partyEnd,
      partyLeftMs: partyEnd !== null ? Math.max(0, partyEnd - t) : 0,
      parties,
      event: liveEvent ? { seq: liveEvent.seq, kind: liveEvent.kind, by: liveEvent.by, gift: liveEvent.gift, count: liveEvent.count } : null,
      toasts: toasts.map((x) => ({ ...x })),
      swaps: swaps.map((x) => ({ ...x })),
      voices: cfg.voiceEnabled ? voices.map((v) => ({ ...v })) : [],
    };
  }

  function reset() {
    energy = 0;
    built = 0;
    partyEnd = null;
    event = null;
    toasts = [];
    for (const p of people.values()) p.score = 0;
  }

  return { onEvent, tick, getState, reset };
}
