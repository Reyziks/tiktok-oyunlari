// Büyük Yolculuk görünümü: durumu WebSocket'ten alır ve çizer; oyun mantığı ana süreçtedir.
import { connectState } from '/common/client.js';
import { fitStage } from '/common/stage.js';
import { startNarrator } from '/common/narrator.js';

const narrator = startNarrator();
let lastSwapSeq = null;
// Yeni yer değiştirmelerde gemiye binenlerin id'leri (ilk durumda hiçbiri).
function swapIns(swaps = []) {
  const top = swaps.reduce((m, x) => Math.max(m, x.seq), 0);
  if (lastSwapSeq === null) { lastSwapSeq = top; return new Set(); }
  if (top < lastSwapSeq) lastSwapSeq = 0; // oyun yeniden başladı
  const ids = new Set(swaps.filter((x) => x.seq > lastSwapSeq).map((x) => x.inId));
  lastSwapSeq = Math.max(lastSwapSeq, top);
  return ids;
}

const GAME_ID = 'buyuk-yolculuk';
const SHIRTS = ['#1e88e5', '#ff8f00', '#00a884', '#e84393', '#7c4dff', '#d63031', '#00acc1', '#f39c12', '#2ecc71', '#e17055'];
const DECK_W = 820;
const DANGER = {
  storm: { icon: '⛈️', title: 'FIRTINA! Hep birlikte kürek çekin!' },
  monster: { icon: '🐙', title: 'DENİZ CANAVARI! Birlikte savuşturun!' },
  fog: { icon: '🌫️', title: 'YOĞUN SİS! Fenere doğru kürek çekin!' },
};

const $ = (id) => document.getElementById(id);
const stage = $('stage');
const el = {
  crowd: $('crowd'), routeFill: $('route-fill'), routeMarks: $('route-marks'), routeShip: $('route-ship'), routeText: $('route-text'),
  danger: $('danger'), dangerIcon: $('danger-icon'), dangerTitle: $('danger-title'), dangerFill: $('danger-fill'), dangerInfo: $('danger-info'),
  deck: $('deck'), weather: $('weather'), monster: $('monster'), fx: $('fx'), more: $('more'),
  port: $('port'), portSub: $('port-sub'), captain: $('captain'), portNext: $('port-next'),
  news: $('news'), howto: $('howto-main'), idle: $('idle'), idleText: $('idle-text'),
};

// ---------- yardımcılar ----------
const fmt = (n) => Math.round(Number(n) || 0).toLocaleString('tr-TR');
const setText = (node, t) => { const s = String(t); if (node.textContent !== s) node.textContent = s; };
const hash = (s) => { let h = 0; for (const ch of String(s)) h = (Math.imul(h, 31) + ch.codePointAt(0)) | 0; return Math.abs(h); };
const seg = typeof Intl.Segmenter === 'function' ? new Intl.Segmenter('tr', { granularity: 'grapheme' }) : null;
function initialOf(name) {
  const s = String(name ?? '').trim();
  if (!s) return '?';
  return (seg ? seg.segment(s)[Symbol.iterator]().next().value.segment : Array.from(s)[0]).toLocaleUpperCase('tr');
}
const failed = new Set();
function setAvatar(node, p) {
  const key = `${p.avatarUrl}|${p.nickname}`;
  if (node.dataset.key === key) return;
  node.dataset.key = key;
  node.style.setProperty('--av-bg', SHIRTS[hash(p.id) % SHIRTS.length]);
  const initial = () => { node.replaceChildren(); node.textContent = initialOf(p.nickname); };
  if (!p.avatarUrl || failed.has(p.avatarUrl)) return initial();
  const img = document.createElement('img');
  img.alt = '';
  img.referrerPolicy = 'no-referrer';
  img.addEventListener('error', () => { failed.add(p.avatarUrl); if (img.parentNode === node) initial(); });
  img.src = p.avatarUrl;
  node.replaceChildren(img);
}
const rnd = (a, b) => a + Math.random() * (b - a);
function spawn(cls, text, style, ms) {
  const d = document.createElement('div');
  d.className = cls;
  if (text) d.textContent = text;
  Object.assign(d.style, style);
  el.fx.append(d);
  setTimeout(() => d.remove(), ms);
  return d;
}

// ---------- rota ----------
let marksBuilt = false;
function renderRoute(s) {
  if (!marksBuilt) {
    for (const isl of s.islands) {
      const m = document.createElement('span');
      m.textContent = '🏝️';
      m.style.left = `${isl.at * 100}%`;
      m.title = isl.name;
      el.routeMarks.append(m);
    }
    marksBuilt = true;
  }
  [...el.routeMarks.children].forEach((m, i) => m.classList.toggle('on', s.islands[i]?.reached));
  const pct = `${(Math.min(1, s.progress) * 100).toFixed(1)}%`;
  el.routeFill.style.width = pct;
  el.routeShip.style.left = pct;
  const next = s.islands.find((i) => !i.reached);
  setText(el.routeText, `${fmt(s.distance)} / ${fmt(s.routeLength)} deniz mili${next ? ` · sıradaki: ${next.name}` : ' · liman yakın!'}`);
}

// ---------- tayfa ----------
const mates = new Map();
function createMate(m) {
  const root = document.createElement('div');
  root.className = 'mate';
  root.innerHTML = '<div class="fig"><div class="hat">🎩</div><div class="head avatar"></div><div class="body"></div><div class="name"></div></div>';
  root.querySelector('.body').style.setProperty('--shirt', SHIRTS[(hash(m.id) >> 3) % SHIRTS.length]);
  const fig = root.querySelector('.fig');
  fig.addEventListener('animationend', (e) => { if (e.animationName === 'row') fig.classList.remove('row'); });
  el.deck.append(root);
  return { root, fig, name: root.querySelector('.name'), avatar: root.querySelector('.avatar'), bubble: null, rowSeq: m.rowSeq, bubbleSeq: m.bubbleSeq };
}
function renderCrew(crew) {
  const sorted = [...crew].sort((a, b) => a.slot - b.slot);
  const perRow = Math.max(1, Math.ceil(sorted.length / 2));
  el.deck.classList.toggle('dense', perRow > 8);
  const seen = new Set();
  sorted.forEach((m, i) => {
    seen.add(m.id);
    let n = mates.get(m.id);
    if (!n) { n = createMate(m); mates.set(m.id, n); }
    const row = i % 2;
    const k = Math.floor(i / 2);
    n.root.classList.toggle('row2', row === 1);
    n.root.style.left = `${((k + 0.5 + row * 0.5) / (perRow + 0.5)) * DECK_W}px`;
    n.root.style.zIndex = String(row === 1 ? 1 : 2);
    n.root.classList.toggle('captain', m.captain);
    setText(n.name, m.nickname);
    setAvatar(n.avatar, m);
    if (m.rowSeq !== n.rowSeq) {
      n.rowSeq = m.rowSeq;
      n.fig.classList.remove('row');
      void n.fig.offsetWidth;
      n.fig.classList.add('row');
      if (Math.random() < 0.35) spawn('splash', '💦', { left: `${rnd(150, 950)}px`, top: `${rnd(1220, 1300)}px` }, 1000);
    }
    if (m.bubble && m.bubbleSeq !== n.bubbleSeq) {
      n.bubble?.remove();
      n.bubble = document.createElement('div');
      n.bubble.className = 'bubble';
      n.bubble.textContent = m.bubble;
      n.fig.append(n.bubble);
    } else if (!m.bubble && n.bubble) {
      n.bubble.remove();
      n.bubble = null;
    }
    n.bubbleSeq = m.bubbleSeq;
  });
  for (const [id, n] of mates) if (!seen.has(id)) { n.root.remove(); mates.delete(id); }
}

// ---------- tehlike ----------
function renderDanger(s) {
  const c = s.challenge;
  el.danger.classList.toggle('hidden', !c);
  el.weather.className = `weather${c?.kind === 'storm' ? ' storm' : c?.kind === 'fog' ? ' fog' : ''}`;
  el.monster.classList.toggle('hidden', c?.kind !== 'monster');
  if (!c) return;
  const d = DANGER[c.kind] ?? DANGER.storm;
  setText(el.dangerIcon, d.icon);
  setText(el.dangerTitle, d.title);
  el.dangerFill.style.width = `${Math.min(100, (c.gathered / c.need) * 100).toFixed(1)}%`;
  setText(el.dangerInfo, `${fmt(c.gathered)} / ${fmt(c.need)} güç · ${Math.ceil(c.leftMs / 1000)} sn`);
}

// ---------- liman ----------
let wasPort = false;
let portFx = null;
function fireworks(n) {
  const colors = ['#ffd23f', '#ff4f7a', '#4fc3ff', '#3ddc84', '#ffffff'];
  for (let i = 0; i < n; i++) {
    const f = spawn('firework', '', { left: `${rnd(100, 980)}px`, top: `${rnd(250, 800)}px`, animationDelay: `${rnd(0, 1.5)}s` }, 3000);
    f.style.setProperty('--c', colors[i % colors.length]);
  }
}
function renderPort(s) {
  const port = s.phase === 'port';
  el.port.classList.toggle('hidden', !port);
  if (port && !wasPort) {
    fireworks(20);
    portFx = setInterval(() => fireworks(8), 1600);
    setText(el.portSub, `${s.voyages}. yolculuk tamamlandı · ${fmt(s.total)} tayfa`);
    el.captain.replaceChildren();
    if (s.captain) {
      const head = document.createElement('div');
      head.className = 'head avatar';
      setAvatar(head, s.captain);
      const name = document.createElement('div');
      name.textContent = `🎩 ${s.captain.nickname}`;
      const sub = document.createElement('small');
      sub.textContent = `Yolculuğun kaptanı · ${fmt(s.captain.power)} güç`;
      el.captain.append(head, name, sub);
    }
  } else if (!port && wasPort) {
    clearInterval(portFx);
  }
  if (port) setText(el.portNext, `Yeni yolculuk ${Math.ceil(s.portLeftMs / 1000)} sn sonra`);
  wasPort = port;
}

// ---------- haberler (sırayla) ----------
let lastNewsSeq = null;
const newsQueue = [];
let newsTimer = null;
function queueNews(news) {
  if (lastNewsSeq === null) { lastNewsSeq = news.at(-1)?.seq ?? 0; return; }
  for (const n of news) if (n.seq > lastNewsSeq) newsQueue.push(n);
  if (news.length) lastNewsSeq = Math.max(lastNewsSeq, news.at(-1).seq);
  if (!newsTimer) showNews();
}
function showNews() {
  const n = newsQueue.shift();
  if (!n) { el.news.classList.add('hidden'); newsTimer = null; return; }
  setText(el.news, n.text);
  el.news.classList.remove('hidden');
  el.news.style.animation = 'none';
  void el.news.offsetWidth;
  el.news.style.animation = '';
  if (n.kind === 'gift' && n.text.startsWith('🚀')) spawn('rocket', '🚀', {}, 2500);
  if (n.kind === 'gift' && n.text.startsWith('💨')) for (let i = 0; i < 6; i++) spawn('puff', '💨', { left: `${rnd(700, 1000)}px`, top: `${rnd(900, 1150)}px`, animationDelay: `${i * 0.12}s` }, 2000);
  if (n.kind === 'win' || n.kind === 'island') fireworks(10);
  newsTimer = setTimeout(showNews, newsQueue.length > 2 ? 1500 : 2800);
}

// ---------- ana çizim ----------
function render(s) {
  setText(el.crowd, `⛵ ${fmt(s.total)} tayfa gemide${s.voyages ? ` · ${s.voyages} yolculuk` : ''}`);
  renderRoute(s);
  const fresh = swapIns(s.swaps);
  renderCrew(s.crew);
  for (const id of fresh) {
    const n = mates.get(id);
    if (!n) continue;
    n.root.classList.remove('swapin');
    void n.root.offsetWidth; // animasyonu yeniden başlat
    n.root.classList.add('swapin');
  }
  narrator.handle(s);
  const more = s.total - s.crew.length;
  el.more.classList.toggle('hidden', more <= 0);
  if (more > 0) setText(el.more, `+${fmt(more)} tayfa sırada`);
  // Hız arttıkça dalgalar ve bulutlar hızlanır; durgunken de yavaşça akar.
  const speed = Math.max(1.2, 7 - Math.min(5.8, s.speed / 40));
  stage.style.setProperty('--speed', `${speed.toFixed(2)}s`);
  renderDanger(s);
  renderPort(s);
  queueNews(Array.isArray(s.news) ? s.news : []);
}

const TIPS = ['Beğen → kürek çek · Yorum → konuş · Hediye → rüzgâr ve roket', '💬 Yorumun güvertede balon olur', '🎩 En çok güç veren yolculuğun kaptanı olur', '⚠️ Tehlike gelince hep birlikte beğen!', '🚀 Büyük hediye → gemiye roket'];
let tip = 0;
setInterval(() => {
  el.howto.classList.add('fade');
  setTimeout(() => { setText(el.howto, TIPS[++tip % TIPS.length]); el.howto.classList.remove('fade'); }, 350);
}, 4500);

function onMessage(msg) {
  if (msg?.type === 'state' && msg.gameId === GAME_ID && msg.state) {
    el.idle.classList.add('hidden');
    render(msg.state);
  } else if (msg?.type === 'idle' || msg?.type === 'state') {
    setText(el.idleText, 'Oyun başlatılmadı');
    el.idle.classList.remove('hidden');
  }
}

fitStage(stage);
connectState(onMessage);
