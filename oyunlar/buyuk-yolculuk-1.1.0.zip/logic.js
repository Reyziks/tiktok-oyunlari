// Büyük Yolculuk oyun mantığı: herkes aynı gemide; birlikte ilerlenir, tehlikeler birlikte atlatılır.
// Saf ESM modül: saat ve rastgelelik dışarıdan verilir.
import { readFileSync } from 'node:fs';

const manifest = JSON.parse(readFileSync(new URL('./manifest.json', import.meta.url), 'utf8'));
const DEFAULTS = Object.fromEntries(manifest.settings.map((s) => [s.key, s.default]));

const ISLANDS = [
  { name: 'Martı Adası', at: 0.25 },
  { name: 'Mercan Koyu', at: 0.5 },
  { name: 'Fener Burnu', at: 0.75 },
];
const CHALLENGES = {
  storm: 'Fırtına geliyor! Hep birlikte kürek çekin!',
  monster: 'Deniz canavarı gemiye saldırıyor! Hep birlikte savuşturun!',
  fog: 'Yoğun sis! Hep birlikte fenere doğru kürek çekin!',
};
const CHALLENGE_KINDS = Object.keys(CHALLENGES);
const PUSHBACK = 0.05; // atlatılamayan tehlike gemiyi yolun %5'i kadar geri iter
const SPEED_WINDOW_MS = 5000;
const BUBBLE_MAX = 60;
const BIG_GIFT = 99;
const NEWS_LIMIT = 6;
const SWAPS_KEPT = 8;
const VOICES_KEPT = 4;
const PEOPLE_MAX = 5000;

function resolveSettings(input = {}) {
  const out = { ...DEFAULTS };
  for (const [key, def] of Object.entries(DEFAULTS)) {
    const v = input[key];
    if (v === undefined || v === null || v === '') continue;
    if (typeof def === 'number') {
      const n = Number(v);
      if (Number.isFinite(n)) out[key] = n;
    } else if (typeof def === 'boolean') {
      out[key] = typeof v === 'boolean' ? v : String(v) !== 'false';
    } else {
      out[key] = String(v);
    }
  }
  return out;
}

export function create(settings, { now = Date.now, random = Math.random } = {}) {
  const cfg = resolveSettings(settings);
  const crew = new Map(); // id → tayfa
  let seq = 0;
  let phase = 'sailing';
  let distance = 0;
  let voyages = 0;
  let reached = ISLANDS.map(() => false);
  let challenge = null; // { kind, need, gathered, endsAt }
  let nextChallengeAt = now() + cfg.challengeEverySec * 1000;
  let portEnd = null;
  let news = []; // son haberler [{ seq, kind, text }], ekran sırayla gösterir
  let lastResult = null;
  let captain = null; // limanda gösterilen yolculuk kaptanı
  let recent = []; // [{ at, n }] hız için
  let seats = []; // ekrandaki yerler: tayfa id ya da null (en fazla maxVisible)
  let swaps = []; // [{ seq, seat, outId, inId }]
  let voices = []; // [{ seq, cue }] sunucu sesi işaretleri

  const cue = (name) => {
    voices.push({ seq: ++seq, cue: name });
    if (voices.length > VOICES_KEPT) voices = voices.slice(-VOICES_KEPT);
  };
  const isAfk = (m, t) => m.lastActiveAt <= t - cfg.afkSec * 1000;
  const seated = (id) => seats.includes(id);

  // Boş yer varsa gelen hemen biner; dolu yerdeki aktif tayfa asla indirilmez.
  function seat(m) {
    if (seated(m.id)) return;
    let i = seats.indexOf(null);
    if (i < 0 && seats.length < cfg.maxVisible) i = seats.length;
    if (i >= 0) seats[i] = m.id;
  }

  // AFK olanın yerine, bekleyenlerden en yüksek puanlı gelir ve yerini (slot) devralır.
  function fillSeats(t) {
    for (let i = 0; i < seats.length; i++) {
      const id = seats[i];
      const m = id && crew.get(id);
      if (m && !isAfk(m, t)) continue;
      let best = null;
      for (const c of crew.values()) {
        if (seated(c.id) || isAfk(c, t)) continue;
        if (!best || c.score > best.score || (c.score === best.score && c.lastActiveAt > best.lastActiveAt)) best = c;
      }
      seats[i] = best ? best.id : null;
      if (best && m) {
        best.slot = m.slot;
        swaps.push({ seq: ++seq, seat: i, outId: m.id, inId: best.id });
        if (swaps.length > SWAPS_KEPT) swaps = swaps.slice(-SWAPS_KEPT);
      }
    }
  }

  function prune(t) {
    if (crew.size <= PEOPLE_MAX) return;
    const idle = [...crew.values()].filter((m) => !seated(m.id) && isAfk(m, t)).sort((a, b) => a.score - b.score);
    for (const m of idle.slice(0, crew.size - PEOPLE_MAX)) crew.delete(m.id);
  }

  const say = (kind, text) => {
    news.push({ seq: ++seq, kind, text });
    if (news.length > NEWS_LIMIT) news = news.slice(-NEWS_LIMIT);
  };

  function memberOf(user) {
    let m = crew.get(user.id);
    if (!m) {
      m = { id: user.id, nickname: user.nickname || user.uniqueId || user.id, avatarUrl: user.avatarUrl || '', slot: random(), bubble: null, bubbleSeq: 0, bubbleUntil: 0, rowSeq: 0, power: 0, score: 0, lastActiveAt: now() };
      crew.set(user.id, m);
    } else {
      if (user.nickname) m.nickname = user.nickname;
      if (user.avatarUrl) m.avatarUrl = user.avatarUrl;
    }
    m.lastActiveAt = now();
    return m;
  }

  function topContributor() {
    let best = null;
    for (const m of crew.values()) if (m.power > 0 && (!best || m.power > best.power)) best = m;
    return best;
  }

  function arrive() {
    phase = 'port';
    distance = cfg.routeLength;
    voyages++;
    const cap = topContributor();
    captain = cap ? { id: cap.id, nickname: cap.nickname, avatarUrl: cap.avatarUrl, power: cap.power } : null;
    portEnd = now() + cfg.portSec * 1000;
    say('port', `⚓ Limana vardık! ${voyages}. yolculuk tamamlandı`);
    cue('port');
  }

  function advance(n) {
    distance = Math.min(cfg.routeLength, distance + n);
    ISLANDS.forEach((isl, i) => {
      if (!reached[i] && distance >= isl.at * cfg.routeLength) {
        reached[i] = true;
        say('island', `🏝️ ${isl.name}'na ulaştık!`);
        if (distance < cfg.routeLength) cue('island');
      }
    });
    if (distance >= cfg.routeLength) arrive();
  }

  function power(m, n) {
    if (!(n > 0)) return;
    m.score += n; // ekranda kalma puanı limanda da birikir, seferler arasında sıfırlanmaz
    if (phase === 'port') return;
    m.power += n;
    recent.push({ at: now(), n });
    if (phase === 'challenge') {
      challenge.gathered += n;
      if (challenge.gathered >= challenge.need) {
        const bonus = challenge.need;
        lastResult = { seq: ++seq, kind: challenge.kind, success: true };
        say('win', '🎉 Tehlikeyi birlikte atlattık! Gemi hızlandı!');
        cue('challenge_won');
        challenge = null;
        phase = 'sailing';
        nextChallengeAt = now() + cfg.challengeEverySec * 1000;
        advance(bonus);
      }
      return;
    }
    advance(n);
  }

  function onEvent(evt) {
    if (!evt || !evt.user || !evt.user.id) return;
    const m = memberOf(evt.user);
    switch (evt.type) {
      case 'like':
        m.rowSeq++;
        power(m, Math.max(0, Number(evt.likeCount) || 0) * cfg.likePower);
        break;
      case 'comment': {
        const text = String(evt.comment ?? '').trim().slice(0, BUBBLE_MAX);
        if (text) {
          m.bubble = text;
          m.bubbleSeq = ++seq;
          m.bubbleUntil = now() + cfg.bubbleSec * 1000;
        }
        power(m, cfg.commentPower);
        break;
      }
      case 'gift': {
        const g = evt.gift;
        if (!g || !g.final) break;
        const diamonds = Math.max(0, Number(g.diamonds) || 0) * Math.max(1, Number(g.count) || 1);
        if (diamonds >= BIG_GIFT) {
          say('gift', `🚀 ${m.nickname} gemiye roket bağladı!`);
          cue('big_gift');
        }
        else if (diamonds > 0) say('gift', `💨 ${m.nickname} yelkenlere rüzgâr gönderdi!`);
        m.rowSeq++;
        power(m, diamonds * cfg.diamondPower);
        break;
      }
      case 'follow':
        power(m, cfg.followPower);
        break;
      case 'share':
        power(m, cfg.sharePower);
        break;
      default:
        break;
    }
    seat(m);
  }

  function tick(nowMs) {
    if (phase === 'port' && nowMs >= portEnd) {
      phase = 'sailing';
      distance = 0;
      reached = ISLANDS.map(() => false);
      for (const m of crew.values()) m.power = 0;
      captain = null;
      portEnd = null;
      nextChallengeAt = nowMs + cfg.challengeEverySec * 1000;
      say('start', '⛵ Yeni yolculuk başladı! Hep birlikte kürek çekin!');
      cue('voyage_start');
    } else if (phase === 'challenge' && nowMs >= challenge.endsAt) {
      lastResult = { seq: ++seq, kind: challenge.kind, success: false };
      distance = Math.max(0, distance - PUSHBACK * cfg.routeLength);
      say('lose', '🌊 Tehlike gemiyi geri itti! Tekrar deneyelim!');
      cue('challenge_lost');
      challenge = null;
      phase = 'sailing';
      nextChallengeAt = nowMs + cfg.challengeEverySec * 1000;
    } else if (phase === 'sailing' && nowMs >= nextChallengeAt) {
      if (crew.size > 0) {
        const kind = CHALLENGE_KINDS[Math.min(CHALLENGE_KINDS.length - 1, Math.floor(random() * CHALLENGE_KINDS.length))];
        challenge = { kind, need: cfg.challengeNeed, gathered: 0, endsAt: nowMs + cfg.challengeSec * 1000 };
        phase = 'challenge';
        say('challenge', `⚠️ ${CHALLENGES[kind]}`);
        cue('challenge');
      } else {
        nextChallengeAt = nowMs + cfg.challengeEverySec * 1000;
      }
    }
    fillSeats(nowMs);
    prune(nowMs);
    recent = recent.filter((r) => nowMs - r.at < SPEED_WINDOW_MS);
  }

  function getState() {
    const t = now();
    const cap = topContributor();
    const visible = seats.filter(Boolean).map((id) => crew.get(id)).filter(Boolean);
    if (cap && !visible.includes(cap)) {
      if (visible.length >= cfg.maxVisible) visible[visible.length - 1] = cap;
      else visible.push(cap);
    }
    let total = 0;
    for (const m of crew.values()) if (!isAfk(m, t)) total++;
    return {
      phase,
      distance,
      routeLength: cfg.routeLength,
      progress: distance / cfg.routeLength,
      islands: ISLANDS.map((isl, i) => ({ name: isl.name, at: isl.at, reached: reached[i] })),
      voyages,
      total,
      crew: visible.map((m) => ({
        id: m.id,
        nickname: m.nickname,
        avatarUrl: m.avatarUrl,
        slot: m.slot,
        bubble: t < m.bubbleUntil ? m.bubble : null,
        bubbleSeq: m.bubbleSeq,
        rowSeq: m.rowSeq,
        captain: m === cap,
      })),
      challenge: challenge ? { kind: challenge.kind, need: challenge.need, gathered: challenge.gathered, leftMs: Math.max(0, challenge.endsAt - t) } : null,
      lastResult,
      news: news.map((n) => ({ ...n })),
      captain,
      portLeftMs: portEnd !== null ? Math.max(0, portEnd - t) : 0,
      speed: recent.filter((r) => t - r.at < SPEED_WINDOW_MS).reduce((s, r) => s + r.n, 0),
      swaps: swaps.map((x) => ({ ...x })),
      voices: cfg.voiceEnabled ? voices.map((v) => ({ ...v })) : [],
    };
  }

  function reset() {
    phase = 'sailing';
    distance = 0;
    reached = ISLANDS.map(() => false);
    challenge = null;
    portEnd = null;
    captain = null;
    for (const m of crew.values()) {
      m.power = 0;
      m.score = 0;
    }
    nextChallengeAt = now() + cfg.challengeEverySec * 1000;
  }

  return { onEvent, tick, getState, reset };
}
