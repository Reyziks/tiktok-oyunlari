// Canlı Meydan oyun mantığı. Herkes meydanda kendi karakteriyle görünür; yarışma yok, birlikte enerji toplanır.
// Saf ESM modül: saat ve rastgelelik dışarıdan verilir.
import { readFileSync } from 'node:fs';

const manifest = JSON.parse(readFileSync(new URL('./manifest.json', import.meta.url), 'utf8'));
const DEFAULTS = Object.fromEntries(manifest.settings.map((s) => [s.key, s.default]));

const BUBBLE_MAX = 60;
const TOAST_LIMIT = 4;
// Hediye büyüklüğüne (toplam elmas) göre meydan olayı ve süresi.
const EVENTS = [
  { min: 99, kind: 'star', ms: 10000 },
  { min: 20, kind: 'dance', ms: 8000 },
  { min: 5, kind: 'hearts', ms: 6000 },
  { min: 0, kind: 'flowers', ms: 6000 },
];
const BUILD_STEPS = [0.25, 0.5, 0.75]; // enerji oranı: çeşme, sahne, dönme dolap

function resolveSettings(input = {}) {
  const out = { ...DEFAULTS };
  for (const [key, def] of Object.entries(DEFAULTS)) {
    const n = Number(input[key]);
    if (input[key] !== undefined && input[key] !== null && input[key] !== '' && Number.isFinite(n)) out[key] = typeof def === 'number' ? n : input[key];
  }
  return out;
}

export function create(settings, { now = Date.now, random = Math.random } = {}) {
  const cfg = resolveSettings(settings);
  const people = new Map(); // id → kişi
  let seq = 0;
  let energy = 0;
  let built = 0;
  let parties = 0;
  let partyEnd = null;
  let event = null; // { seq, kind, by, byId, until }
  let toasts = [];

  const at = () => now();

  function personOf(user) {
    let p = people.get(user.id);
    if (!p) {
      p = {
        id: user.id,
        nickname: user.nickname || user.uniqueId || user.id,
        avatarUrl: user.avatarUrl || '',
        x: 0.05 + random() * 0.9,
        y: random(),
        bubble: null,
        bubbleSeq: 0,
        bubbleUntil: 0,
        jumpSeq: 0,
        lastActiveAt: at(),
      };
      people.set(user.id, p);
    } else {
      if (user.nickname) p.nickname = user.nickname;
      if (user.avatarUrl) p.avatarUrl = user.avatarUrl;
    }
    p.lastActiveAt = at();
    return p;
  }

  function addEnergy(n) {
    if (partyEnd !== null || !(n > 0)) return; // parti sırasında enerji birikmez
    energy += n;
    for (let i = BUILD_STEPS.length; i > 0; i--) {
      if (energy >= BUILD_STEPS[i - 1] * cfg.partyEnergy) {
        built = Math.max(built, i);
        break;
      }
    }
    if (energy >= cfg.partyEnergy) {
      energy = 0;
      parties++;
      partyEnd = at() + cfg.partySec * 1000;
    }
  }

  function toast(text) {
    toasts.push({ id: `t${++seq}`, text });
    if (toasts.length > TOAST_LIMIT) toasts = toasts.slice(-TOAST_LIMIT);
  }

  function onGift(p, g) {
    if (!g || !g.final) return; // seri hediye: puan ve olay seri bitince
    const diamonds = Math.max(0, Number(g.diamonds) || 0) * Math.max(1, Number(g.count) || 1);
    const def = EVENTS.find((e) => diamonds >= e.min);
    event = { seq: ++seq, kind: def.kind, by: p.nickname, byId: p.id, gift: g.name, count: g.count, until: at() + def.ms };
    addEnergy(diamonds * cfg.diamondEnergy);
  }

  function onEvent(evt) {
    if (!evt || !evt.user || !evt.user.id) return;
    const p = personOf(evt.user);
    switch (evt.type) {
      case 'comment': {
        const text = String(evt.comment ?? '').trim().slice(0, BUBBLE_MAX);
        if (text) {
          p.bubble = text;
          p.bubbleSeq = ++seq;
          p.bubbleUntil = at() + cfg.bubbleSec * 1000;
        }
        addEnergy(cfg.commentEnergy);
        break;
      }
      case 'like':
        p.jumpSeq++;
        addEnergy(Math.max(0, Number(evt.likeCount) || 0) * cfg.likeEnergy);
        break;
      case 'gift':
        onGift(p, evt.gift);
        break;
      case 'follow':
        toast(`${p.nickname} takip etti ⭐`);
        addEnergy(cfg.followEnergy);
        break;
      case 'share':
        toast(`${p.nickname} yayını paylaştı 📣`);
        addEnergy(cfg.shareEnergy);
        break;
      default:
        break;
    }
  }

  function tick(nowMs) {
    if (event && nowMs >= event.until) event = null;
    if (partyEnd !== null && nowMs >= partyEnd) partyEnd = null;
    const cutoff = nowMs - cfg.idleMinutes * 60 * 1000;
    for (const [id, p] of people) {
      if (p.lastActiveAt <= cutoff) people.delete(id);
    }
  }

  function getState() {
    const t = at();
    const liveEvent = event && t < event.until ? event : null;
    const starId = liveEvent?.kind === 'star' ? liveEvent.byId : null;
    const sorted = [...people.values()].sort((a, b) => b.lastActiveAt - a.lastActiveAt);
    const visible = sorted.slice(0, cfg.maxVisible);
    if (starId && !visible.some((p) => p.id === starId) && people.has(starId)) visible[visible.length - 1] = people.get(starId);
    return {
      total: people.size,
      people: visible.map((p) => ({
        id: p.id,
        nickname: p.nickname,
        avatarUrl: p.avatarUrl,
        x: p.x,
        y: p.y,
        bubble: t < p.bubbleUntil ? p.bubble : null,
        bubbleSeq: p.bubbleSeq,
        jumpSeq: p.jumpSeq,
        star: p.id === starId,
      })),
      energy,
      partyEnergy: cfg.partyEnergy,
      built,
      party: partyEnd !== null && t < partyEnd,
      partyLeftMs: partyEnd !== null ? Math.max(0, partyEnd - t) : 0,
      parties,
      event: liveEvent ? { seq: liveEvent.seq, kind: liveEvent.kind, by: liveEvent.by, gift: liveEvent.gift, count: liveEvent.count } : null,
      toasts: toasts.map((x) => ({ ...x })),
    };
  }

  function reset() {
    energy = 0;
    built = 0;
    partyEnd = null;
    event = null;
    toasts = [];
  }

  return { onEvent, tick, getState, reset };
}
