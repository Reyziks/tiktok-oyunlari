// Canlı Meydan görünümü: durumu WebSocket'ten alır ve çizer; oyun mantığı ana süreçtedir.
import { connectState } from '/common/client.js';
import { fitStage } from '/common/stage.js';

const GAME_ID = 'canli-meydan';
const SHIRTS = ['#7c4dff', '#ff8f00', '#00a884', '#e84393', '#1e88e5', '#d63031', '#8e44ad', '#00acc1', '#f39c12', '#e17055', '#2ecc71', '#fd79a8'];
const STAGE_SPOT = { x: 0.5, y: -0.55 }; // yıldızın sahnedeki yeri (meydan koordinatı)

const $ = (id) => document.getElementById(id);
const stage = $('stage');
const el = {
  crowd: $('crowd'), fill: $('energy-fill'), energyText: $('energy-text'), plaza: $('plaza'), people: $('people'),
  fx: $('fx'), toasts: $('toasts'), more: $('more'), announce: $('announce'), spotlight: $('spotlight'),
  howto: $('howto-main'), idle: $('idle'), idleText: $('idle-text'),
  deco: { 1: $('deco-fountain'), 2: $('deco-stage'), 3: $('deco-wheel') },
  steps: [...document.querySelectorAll('.milestones span')],
};

// ---------- yardımcılar ----------
const fmt = (n) => Math.round(Number(n) || 0).toLocaleString('tr-TR');
const setText = (node, t) => { const s = String(t); if (node.textContent !== s) node.textContent = s; };
const hash = (s) => { let h = 0; for (const ch of String(s)) h = (Math.imul(h, 31) + ch.codePointAt(0)) | 0; return Math.abs(h); };
const seg = typeof Intl.Segmenter === 'function' ? new Intl.Segmenter('tr', { granularity: 'grapheme' }) : null;
function initialOf(name) {
  const s = String(name ?? '').trim();
  if (!s) return '?';
  return (seg ? seg.segment(s)[Symbol.iterator]().next().value.segment : Array.from(s)[0]).toLocaleUpperCase('tr');
}
const failed = new Set();
function setAvatar(node, p) {
  const key = `${p.avatarUrl}|${p.nickname}`;
  if (node.dataset.key === key) return;
  node.dataset.key = key;
  node.style.setProperty('--av-bg', SHIRTS[hash(p.id) % SHIRTS.length]);
  const initial = () => { node.replaceChildren(); node.textContent = initialOf(p.nickname); };
  if (!p.avatarUrl || failed.has(p.avatarUrl)) return initial();
  const img = document.createElement('img');
  img.alt = '';
  img.referrerPolicy = 'no-referrer';
  img.addEventListener('error', () => { failed.add(p.avatarUrl); if (img.parentNode === node) initial(); });
  img.src = p.avatarUrl;
  node.replaceChildren(img);
}

// ---------- kişiler ----------
const nodes = new Map(); // id → { root, fig, bubble, name, avatar, jumpSeq, bubbleSeq }

function place(p) {
  const pos = p.star ? STAGE_SPOT : p;
  const x = 60 + pos.x * 960;
  const y = 470 + pos.y * 360; // ayak hizası (meydan içinde)
  const scale = 0.72 + Math.max(0, pos.y) * 0.4;
  return { transform: `translate(${x}px, ${y}px) scale(${p.star ? 1.15 : scale})`, z: Math.round(100 + pos.y * 100) + (p.star ? 500 : 0) };
}

function createPerson(p) {
  const root = document.createElement('div');
  root.className = 'person';
  root.innerHTML = '<div class="wander"><div class="fig"><div class="head avatar"></div><div class="body"></div><div class="name"></div></div></div>';
  const h = hash(p.id);
  root.style.setProperty('--wd', `${4 + (h % 5)}s`);
  root.style.setProperty('--wdelay', `-${h % 7}s`);
  root.style.setProperty('--dd', `-${(h % 10) / 20}s`);
  root.querySelector('.body').style.setProperty('--shirt', SHIRTS[(h >> 3) % SHIRTS.length]);
  const fig = root.querySelector('.fig');
  fig.addEventListener('animationend', (e) => { if (e.animationName === 'jump') fig.classList.remove('jump'); });
  const n = { root, fig, name: root.querySelector('.name'), avatar: root.querySelector('.avatar'), bubble: null, jumpSeq: p.jumpSeq, bubbleSeq: p.bubbleSeq };
  el.people.append(root);
  return n;
}

function renderPeople(people) {
  const seen = new Set();
  for (const p of people) {
    seen.add(p.id);
    let n = nodes.get(p.id);
    if (!n) {
      n = createPerson(p);
      nodes.set(p.id, n);
    }
    const { transform, z } = place(p);
    if (n.root.style.transform !== transform) n.root.style.transform = transform;
    n.root.style.zIndex = String(z);
    n.root.classList.toggle('star', p.star);
    setText(n.name, p.nickname);
    setAvatar(n.avatar, p);
    if (p.jumpSeq !== n.jumpSeq) {
      n.jumpSeq = p.jumpSeq;
      n.fig.classList.remove('jump');
      void n.fig.offsetWidth;
      n.fig.classList.add('jump');
    }
    if (p.bubble && p.bubbleSeq !== n.bubbleSeq) {
      n.bubble?.remove();
      n.bubble = document.createElement('div');
      n.bubble.className = 'bubble';
      n.bubble.textContent = p.bubble;
      n.fig.append(n.bubble);
    } else if (!p.bubble && n.bubble) {
      n.bubble.remove();
      n.bubble = null;
    }
    n.bubbleSeq = p.bubbleSeq;
  }
  for (const [id, n] of nodes) {
    if (!seen.has(id)) {
      n.root.remove();
      nodes.delete(id);
    }
  }
}

// ---------- efektler ----------
function spawn(cls, text, style, ms) {
  const d = document.createElement('div');
  d.className = cls;
  if (text) d.textContent = text;
  Object.assign(d.style, style);
  el.fx.append(d);
  setTimeout(() => d.remove(), ms);
  return d;
}
const rnd = (a, b) => a + Math.random() * (b - a);
function rain(chars, n) {
  for (let i = 0; i < n; i++) {
    const d = spawn('drop', chars[i % chars.length], { left: `${rnd(0, 1040)}px`, animationDelay: `${rnd(0, 2.5)}s` }, 7000);
    d.style.setProperty('--fd', `${rnd(3, 5)}s`);
    d.style.setProperty('--fx', `${rnd(-120, 120)}px`);
    d.style.setProperty('--fr', `${rnd(-360, 360)}deg`);
  }
}
function heartsFromPeople() {
  for (const n of nodes.values()) {
    const r = n.root.getBoundingClientRect();
    const s = stage.getBoundingClientRect();
    const k = 1080 / s.width;
    spawn('float', ['💖', '💗', '💕'][hash(n.root.textContent) % 3], { left: `${(r.left - s.left) * k - 25}px`, top: `${(r.top - s.top) * k - 200}px` }, 2300);
  }
}
function fireworks(n) {
  const colors = ['#ffd23f', '#ff4fa3', '#4fc3ff', '#3ddc84', '#ffffff'];
  for (let i = 0; i < n; i++) {
    const f = spawn('firework', '', { left: `${rnd(100, 980)}px`, top: `${rnd(250, 750)}px`, animationDelay: `${rnd(0, 1.5)}s` }, 3000);
    f.style.setProperty('--c', colors[i % colors.length]);
  }
}
let disco = null;
function setDisco(on) {
  if (on && !disco) {
    disco = document.createElement('div');
    disco.className = 'disco';
    el.plaza.append(disco);
  } else if (!on && disco) {
    disco.remove();
    disco = null;
  }
}

// ---------- olaylar ve duyurular ----------
const EVENT_TEXT = {
  flowers: (e) => `🌸 ${e.by} meydana çiçek yağdırdı!`,
  hearts: (e) => `💖 ${e.by} herkese sevgi gönderdi!`,
  dance: (e) => `🕺 ${e.by} dans partisi başlattı!`,
  star: (e) => `⭐ ${e.by} sahnede!`,
};
let lastEventSeq = null;
let announceTimer = null;
function announce(text, party = false, ms = 3500) {
  setText(el.announce, text);
  el.announce.classList.toggle('party', party);
  el.announce.classList.remove('hidden');
  el.announce.style.animation = 'none';
  void el.announce.offsetWidth;
  el.announce.style.animation = '';
  clearTimeout(announceTimer);
  if (!party) announceTimer = setTimeout(() => el.announce.classList.add('hidden'), ms);
}
function startEvent(e) {
  announce(EVENT_TEXT[e.kind]?.(e) ?? '');
  if (e.kind === 'flowers') rain(['🌸', '🌹', '🌺', '🌼'], 40);
  if (e.kind === 'hearts') { heartsFromPeople(); setTimeout(heartsFromPeople, 1200); }
  if (e.kind === 'star') fireworks(14);
}

let wasParty = false;
let partyTimer = null;
function renderParty(s) {
  if (s.party && !wasParty) {
    fireworks(20);
    partyTimer = setInterval(() => fireworks(8), 1800);
  } else if (!s.party && wasParty) {
    clearInterval(partyTimer);
    el.announce.classList.add('hidden');
  }
  if (s.party) announce(`🎉 MEGA PARTİ! ${Math.ceil(s.partyLeftMs / 1000)} sn`, true);
  wasParty = s.party;
}

const toastNodes = new Map();
function renderToasts(toasts) {
  const ids = new Set(toasts.map((t) => t.id));
  for (const [id, n] of toastNodes) if (!ids.has(id)) { n.remove(); toastNodes.delete(id); }
  for (const t of toasts) {
    if (toastNodes.has(t.id)) continue;
    const d = document.createElement('div');
    d.className = 'toast';
    d.textContent = t.text;
    el.toasts.append(d);
    toastNodes.set(t.id, d);
  }
}

// ---------- ana çizim ----------
function render(s) {
  setText(el.crowd, `👥 ${fmt(s.total)} kişi meydanda`);
  const ratio = s.party ? 1 : Math.min(1, s.energy / s.partyEnergy);
  el.fill.style.width = `${(ratio * 100).toFixed(1)}%`;
  el.steps.forEach((st, i) => st.classList.toggle('on', i < s.built || (i === 3 && s.party)));
  for (const step of [1, 2, 3]) el.deco[step].classList.toggle('hidden', s.built < step);
  setText(el.energyText, s.party ? `🎉 ${s.parties}. büyük parti!` : `Meydan enerjisi: ${fmt(s.energy)} / ${fmt(s.partyEnergy)}`);

  renderPeople(s.people);
  const more = s.total - s.people.length;
  el.more.classList.toggle('hidden', more <= 0);
  if (more > 0) setText(el.more, `+${fmt(more)} kişi daha meydanda`);

  const dancing = s.party || s.event?.kind === 'dance';
  el.people.classList.toggle('dance', dancing);
  setDisco(dancing);
  el.spotlight.classList.toggle('hidden', s.event?.kind !== 'star');

  if (lastEventSeq === null) lastEventSeq = s.event?.seq ?? 0;
  else if (s.event && s.event.seq !== lastEventSeq) {
    lastEventSeq = s.event.seq;
    startEvent(s.event);
  }
  renderParty(s);
  renderToasts(s.toasts);
}

// ---------- dönen ipuçları ----------
const TIPS = ['Beğen → zıpla · Yorum → konuş · Hediye → meydanda kutlama', '💬 Yorumun karakterinin üstünde balon olur', '🌹 Küçük hediye → çiçek yağmuru', '👑 Büyük hediye → sahneye çık!', '⚡ Enerji dolunca MEGA PARTİ'];
let tip = 0;
setInterval(() => {
  el.howto.classList.add('fade');
  setTimeout(() => { setText(el.howto, TIPS[++tip % TIPS.length]); el.howto.classList.remove('fade'); }, 350);
}, 4500);

function onMessage(msg) {
  if (msg?.type === 'state' && msg.gameId === GAME_ID && msg.state) {
    el.idle.classList.add('hidden');
    render(msg.state);
  } else if (msg?.type === 'idle' || msg?.type === 'state') {
    setText(el.idleText, 'Oyun başlatılmadı');
    el.idle.classList.remove('hidden');
  }
}

fitStage(stage);
connectState(onMessage);
