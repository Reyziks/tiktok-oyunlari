// Halat Çekme görünümü: sunucudan gelen durumu (≈10 Hz) DOM'a yansıtır.
// DOM her mesajda baştan kurulmaz; öğeler kimliğe göre eklenir/çıkarılır, metinler yalnızca değişince yazılır.
import { connectState } from '/common/client.js';
import { fitStage } from '/common/stage.js';

const GAME_ID = 'halat-cekme';
const TEAMS = ['blue', 'red'];
const SUPPORTER_LIMIT = 5;
const CREW_LIMIT = 8;
const SUP_ROW_H = 54;
const CREW_SHIFT = 30; // karakter gruplarının halatla birlikte kayma payı (px)
const MEDALS = ['🥇', '🥈', '🥉'];
const TITLES = { blue: 'MAVİ TAKIM KAZANDI!', red: 'KIRMIZI TAKIM KAZANDI!', draw: 'BERABERE!' };
const AV_COLORS = ['#7c4dff', '#ff8f00', '#00a884', '#e84393', '#1e88e5', '#d63031', '#8e44ad', '#00acc1', '#f39c12', '#e17055'];
const CONFETTI_COLORS = { blue: ['#2f7bff', '#8fb8ff', '#ffffff', '#ffd23f'], red: ['#ff3b4e', '#ff9aa5', '#ffffff', '#ffd23f'], draw: ['#2f7bff', '#ff3b4e', '#ffd23f', '#ffffff', '#3ddc84'] };

const $ = (id) => document.getElementById(id);
const stage = $('stage');
const el = {
  score: { blue: $('score-blue'), red: $('score-red') },
  count: { blue: $('count-blue'), red: $('count-red') },
  sup: { blue: $('sup-blue'), red: $('sup-red') },
  crew: { blue: $('crew-blue'), red: $('crew-red') },
  mvp: { blue: $('mvp-blue'), red: $('mvp-red') },
  clock: document.querySelector('.clock'),
  clockLabel: $('clock-label'),
  clockTime: $('clock-time'),
  rope: $('rope'),
  lead: $('lead'),
  feed: $('feed'),
  result: $('result'),
  resultTitle: $('result-title'),
  trophy: document.querySelector('.trophy'),
  rsBlue: $('rs-blue'),
  rsRed: $('rs-red'),
  nextRound: $('next-round'),
  confetti: $('confetti'),
  idle: $('idle'),
  idleText: $('idle-text'),
  joinBanner: $('join-banner'),
  jbAvatar: $('jb-avatar'),
  jbName: $('jb-name'),
  jbTeam: $('jb-team'),
  teamCard: $('team-card'),
  tcAvatar: $('tc-avatar'),
  tcName: $('tc-name'),
  tcTeam: $('tc-team'),
  tcPoints: $('tc-points'),
  attract: $('attract'),
  idleHearts: $('idle-hearts'),
  howtoMain: $('howto-main'),
};

const ROPE_D = parseFloat(getComputedStyle(stage).getPropertyValue('--rope-d')) || 170;

// ---------- Yardımcılar ----------
const fmt = (n) => Math.round(Number(n) || 0).toLocaleString('tr-TR');

function fmtTime(ms) {
  const total = Math.max(0, Math.ceil((Number(ms) || 0) / 1000));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}

function setText(node, text) {
  const s = String(text);
  if (node.textContent !== s) node.textContent = s;
}

function hash(s) {
  let h = 0;
  for (const ch of String(s)) h = (Math.imul(h, 31) + ch.codePointAt(0)) | 0;
  return Math.abs(h);
}

const segmenter = typeof Intl.Segmenter === 'function' ? new Intl.Segmenter('tr', { granularity: 'grapheme' }) : null;

// Takma adın ilk harfi, Türkçe kurallarıyla büyük harf (i → İ).
function initialOf(name) {
  const s = String(name ?? '').trim();
  if (!s) return '?';
  const first = segmenter ? segmenter.segment(s)[Symbol.iterator]().next().value.segment : Array.from(s)[0];
  return first.toLocaleUpperCase('tr');
}

const failedAvatars = new Set(); // yüklenemeyen adresler tekrar denenmez

function makeAvatar() {
  const node = document.createElement('div');
  node.className = 'avatar';
  return node;
}

function setAvatar(node, p) {
  const url = p.avatarUrl || '';
  const key = `${url}|${p.nickname}`;
  if (node.dataset.key === key) return;
  node.dataset.key = key;
  node.style.setProperty('--av-bg', AV_COLORS[hash(p.id) % AV_COLORS.length]);
  const showInitial = () => {
    node.replaceChildren();
    node.textContent = initialOf(p.nickname);
  };
  if (!url || failedAvatars.has(url)) {
    showInitial();
    return;
  }
  const img = document.createElement('img');
  img.alt = '';
  img.decoding = 'async';
  img.referrerPolicy = 'no-referrer';
  img.addEventListener('error', () => {
    failedAvatars.add(url);
    if (img.parentNode === node) showInitial();
  });
  img.src = url;
  node.replaceChildren(img);
}

/** Listeyi kimliğe göre kapsayıcıyla eşler: yenileri ekler, olmayanları siler, hepsini günceller. */
function reconcile(container, list, create, update) {
  const existing = new Map();
  for (const child of container.children) if (child.dataset.id) existing.set(child.dataset.id, child);
  const keep = new Set();
  list.forEach((item, i) => {
    const id = String(item.id);
    let node = existing.get(id);
    if (!node) {
      node = create(item);
      node.dataset.id = id;
      container.append(node);
    }
    keep.add(id);
    update(node, item, i);
  });
  for (const [id, node] of existing) if (!keep.has(id)) node.remove();
}

// ---------- Takımların ilk oyuncuları ----------
function createSupRow() {
  const row = document.createElement('div');
  row.className = 'sup-row';
  row.innerHTML = '<span class="sup-rank"></span><span class="sup-name"></span><span class="sup-pts"></span>';
  row.insertBefore(makeAvatar(), row.children[1]);
  return row;
}

function updateSupRow(row, p, i) {
  const [rank, avatar, name, pts] = row.children;
  setText(rank, i + 1);
  setAvatar(avatar, p);
  setText(name, p.nickname);
  setText(pts, fmt(p.points));
  row.classList.toggle('first', i === 0);
  row.style.transform = `translateY(${i * SUP_ROW_H}px)`;
}

function renderSupporters(team, top) {
  const list = top.slice(0, SUPPORTER_LIMIT);
  const box = el.sup[team];
  reconcile(box, list, createSupRow, updateSupRow);
  box.querySelector('.sup-empty').hidden = list.length > 0;
}

// ---------- Karakterler ----------
function createChar() {
  const c = document.createElement('div');
  c.className = 'char';
  c.innerHTML =
    '<div class="mirror"><div class="figure">' +
    '<div class="leg leg-back"></div><div class="leg leg-front"></div>' +
    '<div class="torso"></div><div class="arm"></div>' +
    '<div class="head"></div><div class="crown" hidden></div>' +
    '</div></div>';
  c.querySelector('.head').append(makeAvatar());
  const figure = c.querySelector('.figure');
  figure.addEventListener('animationend', (e) => {
    if (e.target === figure) c.classList.remove('pull');
  });
  return c;
}

function updateChar(c, p, i) {
  c.style.setProperty('--slot', i);
  c.style.zIndex = String(i % 2 === 0 ? 40 - i : 20 - i); // ön sıra önde, merkeze yakın olan en önde
  c.classList.toggle('back', i % 2 === 1);
  const ghost = Boolean(p.ghost);
  c.classList.toggle('ghost', ghost);
  c.querySelector('.crown').hidden = ghost || i !== 0;
  setAvatar(c.querySelector('.avatar'), p);
}

// Oyuncusu olmayan takımda halat boş kalmasın: yarı saydam "?" karakterler.
const GHOSTS = {
  blue: [0, 1, 2].map((i) => ({ id: `ghost-blue-${i}`, nickname: '?', avatarUrl: '', ghost: true })),
  red: [0, 1, 2].map((i) => ({ id: `ghost-red-${i}`, nickname: '?', avatarUrl: '', ghost: true })),
};

function renderCrew(team, top) {
  const list = top.length ? top.slice(0, CREW_LIMIT) : GHOSTS[team];
  reconcile(el.crew[team], list, createChar, updateChar);
}

function pullCrew(team) {
  for (const c of el.crew[team].children) c.classList.add('pull');
}

// ---------- Bildirimler ----------
function createFeedItem() {
  const item = document.createElement('div');
  item.className = 'feed-item';
  item.append(document.createElement('span'));
  return item;
}

function renderFeed(feed) {
  const list = [...feed].reverse(); // en yeni en üstte
  const box = el.feed;
  const wanted = new Set(list.map((f) => String(f.id)));
  for (const child of [...box.children]) if (!wanted.has(child.dataset.id)) child.remove();
  const byId = new Map([...box.children].map((c) => [c.dataset.id, c]));
  list.forEach((f, i) => {
    const id = String(f.id);
    let item = byId.get(id);
    if (!item) {
      item = createFeedItem();
      item.dataset.id = id;
      box.insertBefore(item, box.children[i] || null);
    } else if (box.children[i] !== item) {
      box.insertBefore(item, box.children[i] || null);
    }
    setText(item.firstChild, f.text);
    item.classList.toggle('team-blue', f.team === 'blue');
    item.classList.toggle('team-red', f.team === 'red');
    item.classList.toggle('gift', /x\d+ (gönderdi|🔥)/u.test(f.text));
  });
}

// ---------- Kazanan ekranı ----------
let shownResult = null;

function renderMvp(team, list) {
  const box = el.mvp[team];
  box.replaceChildren();
  if (!list.length) {
    const none = document.createElement('div');
    none.className = 'mvp-none';
    none.textContent = 'Katılan yok';
    box.append(none);
    return;
  }
  list.slice(0, 3).forEach((p, i) => {
    const row = document.createElement('div');
    row.className = 'mvp-row';
    const medal = document.createElement('span');
    medal.className = 'mvp-medal';
    medal.textContent = MEDALS[i];
    const avatar = makeAvatar();
    setAvatar(avatar, p);
    const name = document.createElement('span');
    name.className = 'mvp-name';
    name.textContent = p.nickname;
    const pts = document.createElement('span');
    pts.className = 'mvp-pts';
    pts.textContent = fmt(p.points);
    row.append(medal, avatar, name, pts);
    box.append(row);
  });
}

function spawnConfetti(winner) {
  const colors = CONFETTI_COLORS[winner] || CONFETTI_COLORS.draw;
  const frag = document.createDocumentFragment();
  for (let i = 0; i < 90; i++) {
    const piece = document.createElement('i');
    const r = (min, max) => min + Math.random() * (max - min);
    piece.style.cssText =
      `--x:${r(-2, 100).toFixed(1)}%;--w:${r(12, 22).toFixed(0)}px;--c:${colors[i % colors.length]};` +
      `--d:${r(3.2, 6).toFixed(2)}s;--delay:${r(-6, 0).toFixed(2)}s;--sway:${r(-120, 120).toFixed(0)}px;--spin:${r(360, 1080).toFixed(0)}deg`;
    frag.append(piece);
  }
  el.confetti.replaceChildren(frag);
}

function renderResult(state) {
  const result = state.phase === 'finished' ? state.result : null;
  if (!result) {
    if (shownResult) {
      shownResult = null;
      el.result.classList.add('hidden');
      el.confetti.replaceChildren();
    }
    return;
  }
  if (!shownResult) {
    shownResult = result;
    const winner = TITLES[result.winner] ? result.winner : 'draw';
    el.result.classList.remove('win-blue', 'win-red', 'win-draw');
    el.result.classList.add(`win-${winner}`);
    el.resultTitle.textContent = TITLES[winner];
    el.trophy.textContent = winner === 'draw' ? '🤝' : '🏆';
    for (const team of TEAMS) renderMvp(team, result.mvp?.[team] ?? []);
    spawnConfetti(winner);
    el.result.classList.remove('hidden');
  }
  setText(el.rsBlue, fmt(state.scores?.blue));
  setText(el.rsRed, fmt(state.scores?.red));
  setText(el.nextRound, `Yeni tur ${Math.max(0, Math.ceil(state.timeLeftMs / 1000))} sn sonra başlıyor`);
}

// ---------- Ana çizim ----------
const prevScores = { blue: null, red: null };

function renderScore(team, value) {
  const node = el.score[team];
  const text = fmt(value);
  setText(node, text);
  node.classList.toggle('long', text.length === 6);
  node.classList.toggle('xlong', text.length >= 7);
  const prev = prevScores[team];
  prevScores[team] = value;
  if (prev !== null && value > prev) {
    if (!node.classList.contains('bump')) {
      node.classList.add('bump');
      node.addEventListener('animationend', () => node.classList.remove('bump'), { once: true });
    }
    pullCrew(team);
  }
}

function renderClock(state) {
  const overtime = state.phase === 'overtime';
  const finished = state.phase === 'finished';
  setText(el.clockLabel, overtime ? 'UZATMA' : finished ? 'BİTTİ' : 'SÜRE');
  setText(el.clockTime, finished ? '0:00' : fmtTime(state.timeLeftMs));
  el.clock.classList.toggle('overtime', overtime);
  el.clock.classList.toggle('hurry', !finished && state.timeLeftMs <= 10_000);
}

function renderRope(state) {
  const rope = Math.max(-1, Math.min(1, Number(state.rope) || 0)); // -1 mavi sınırda, +1 kırmızı sınırda
  el.rope.style.transform = `translateX(${(rope * ROPE_D).toFixed(1)}px)`;
  const shift = `translateX(${(rope * CREW_SHIFT).toFixed(1)}px)`;
  el.crew.blue.style.transform = shift;
  el.crew.red.style.transform = shift;

  const diff = (state.scores?.blue ?? 0) - (state.scores?.red ?? 0);
  setText(el.lead, diff === 0 ? 'EŞİT' : `${diff > 0 ? 'MAVİ TAKIM' : 'KIRMIZI TAKIM'} ÖNDE +${fmt(Math.abs(diff))}`);
  el.lead.classList.toggle('lead-blue', diff > 0);
  el.lead.classList.toggle('lead-red', diff < 0);
}

function render(state) {
  for (const team of TEAMS) {
    const info = state.teams?.[team] ?? { count: 0, top: [] };
    const top = Array.isArray(info.top) ? info.top : [];
    renderScore(team, state.scores?.[team] ?? 0);
    setText(el.count[team], fmt(info.count));
    renderSupporters(team, top);
    renderCrew(team, top);
  }
  renderClock(state);
  renderRope(state);
  renderFeed(Array.isArray(state.feed) ? state.feed : []);
  renderResult(state);
  queueJoins(Array.isArray(state.joins) ? state.joins : []);
  renderTeamCard(state.teamCard);
  trackActivity(state);
  if (state.rules) currentRules = state.rules;
}

// ---------- Sessizlik modu: 10 sn kimse puan getirmezse çağrı balonu + yükselen kalpler ----------
const QUIET_MS = 10000;
const ATTRACT_LINES = [
  'Halat seni bekliyor! 💪',
  'İlk puanı kim alacak? ❤️',
  'Bir beğeni bile halatı oynatır! 👆',
  'Takımına güç ver! 🔥',
];
let lastActivityAt = performance.now();
let activitySig = '';
let attractIdx = 0;
let attractTimer = null;
let heartTimer = null;

function trackActivity(state) {
  const sig = `${state.scores?.blue}|${state.scores?.red}|${state.feed?.at(-1)?.id ?? ''}|${state.joins?.at(-1)?.seq ?? ''}`;
  if (sig !== activitySig) {
    activitySig = sig;
    lastActivityAt = performance.now();
  }
  const quiet = state.phase !== 'finished' && performance.now() - lastActivityAt > QUIET_MS;
  setAttract(quiet);
}

function setAttract(on) {
  if (on === Boolean(attractTimer)) return;
  if (on) {
    const step = () => {
      setText(el.attract, ATTRACT_LINES[attractIdx++ % ATTRACT_LINES.length]);
    };
    step();
    el.attract.classList.remove('hidden');
    attractTimer = setInterval(step, 3500);
    heartTimer = setInterval(spawnIdleHeart, 450);
  } else {
    el.attract.classList.add('hidden');
    clearInterval(attractTimer);
    clearInterval(heartTimer);
    attractTimer = heartTimer = null;
  }
}

function spawnIdleHeart() {
  const h = document.createElement('span');
  const blueSide = Math.random() < 0.5;
  h.className = 'idle-heart';
  h.textContent = blueSide ? '💙' : '❤️';
  h.style.left = `${blueSide ? 80 + Math.random() * 260 : 740 + Math.random() * 260}px`;
  h.style.setProperty('--dx', `${Math.round(Math.random() * 120 - 60)}px`);
  el.idleHearts.append(h);
  h.addEventListener('animationend', () => h.remove(), { once: true });
}

// ---------- Alt şeritte dönen ipuçları (puanlar oyun ayarlarından gelir) ----------
let currentRules = null;
let tipIdx = 0;

function tips() {
  const r = currentRules || { likePoints: 1, commentPoints: 2, diamondPoints: 10, followPoints: 20 };
  return [
    'Beğen · Yorum yap · Hediye gönder',
    `❤️ Beğeni = +${fmt(r.likePoints)} puan`,
    `🎁 Hediye = elmas × ${fmt(r.diamondPoints)} puan`,
    `💬 Yorum = +${fmt(r.commentPoints)} puan`,
    `➕ Takip = +${fmt(r.followPoints)} puan`,
  ];
}

setInterval(() => {
  const node = el.howtoMain;
  node.classList.add('fade');
  setTimeout(() => {
    const list = tips();
    setText(node, list[++tipIdx % list.length]);
    node.classList.remove('fade');
  }, 350);
}, 4000);

// ---------- Katılım duyurusu: "🔵 Ayşe — Mavi Takım" sırayla gösterilir ----------
const TEAM_LABEL = { blue: 'Mavi Takım', red: 'Kırmızı Takım' };
const joinQueue = [];
let lastJoinSeq = null;
let joinTimer = null;

function queueJoins(joins) {
  if (lastJoinSeq === null) {
    // Sayfa açıldığında eski katılımlar yeniden duyurulmaz.
    lastJoinSeq = joins.length ? joins.at(-1).seq : 0;
    return;
  }
  for (const j of joins) {
    if (j.seq > lastJoinSeq) joinQueue.push(j);
  }
  if (joins.length) lastJoinSeq = Math.max(lastJoinSeq, joins.at(-1).seq);
  if (!joinTimer) showNextJoin();
}

function showNextJoin() {
  const banner = el.joinBanner;
  if (!joinQueue.length) {
    banner.classList.add('hidden');
    el.lead.classList.remove('dim');
    joinTimer = null;
    return;
  }
  let text;
  let j;
  if (joinQueue.length > 8) {
    // Çok kalabalıkta özetle: son katılan + kaç kişi daha.
    j = joinQueue.at(-1);
    text = `+${joinQueue.length - 1} oyuncu daha katıldı`;
    joinQueue.length = 0;
  } else {
    j = joinQueue.shift();
    text = '';
  }
  banner.classList.remove('team-blue', 'team-red', 'hidden');
  el.lead.classList.add('dim'); // duyuru, önde olan takım yazısının yerini kısa süre alır
  banner.classList.add(j.team === 'red' ? 'team-red' : 'team-blue');
  setAvatar(el.jbAvatar, { id: j.nickname, nickname: j.nickname, avatarUrl: j.avatarUrl });
  setText(el.jbName, j.nickname);
  setText(el.jbTeam, text ? `${TEAM_LABEL[j.team] ?? ''} · ${text}` : TEAM_LABEL[j.team] ?? '');
  banner.classList.remove('pop');
  void banner.offsetWidth; // animasyonu yeniden başlat
  banner.classList.add('pop');
  const ms = joinQueue.length > 3 ? 900 : 2000; // sıra uzunsa hızlan
  joinTimer = setTimeout(showNextJoin, ms);
}

// ---------- 'takım' yazan izleyicinin kartı ----------
let shownCardSeq = null;

function renderTeamCard(card) {
  const node = el.teamCard;
  if (!card) {
    node.classList.add('hidden');
    shownCardSeq = null;
    return;
  }
  if (card.seq === shownCardSeq) return;
  shownCardSeq = card.seq;
  node.classList.remove('team-blue', 'team-red', 'hidden', 'pop');
  node.classList.add(card.team === 'red' ? 'team-red' : 'team-blue');
  setAvatar(el.tcAvatar, { id: card.nickname, nickname: card.nickname, avatarUrl: card.avatarUrl });
  setText(el.tcName, card.nickname);
  setText(el.tcTeam, (TEAM_LABEL[card.team] ?? '').toLocaleUpperCase('tr'));
  setText(el.tcPoints, `Bu tur: ${fmt(card.points)} puan`);
  void node.offsetWidth;
  node.classList.add('pop');
}

function showIdle(text) {
  setText(el.idleText, text);
  el.idle.classList.remove('hidden');
}

function onMessage(msg) {
  if (msg?.type === 'state' && msg.gameId === GAME_ID && msg.state) {
    el.idle.classList.add('hidden');
    render(msg.state);
  } else if (msg?.type === 'idle' || msg?.type === 'state') {
    showIdle('Oyun başlatılmadı');
  }
}

fitStage(stage);
connectState(onMessage);
