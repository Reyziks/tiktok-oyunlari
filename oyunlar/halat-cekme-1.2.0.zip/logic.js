// Halat Çekme oyun mantığı. Saf ESM modül: saat ve rastgelelik dışarıdan verilir.
import { readFileSync } from 'node:fs';

const manifest = JSON.parse(readFileSync(new URL('./manifest.json', import.meta.url), 'utf8'));
const DEFAULTS = Object.fromEntries(manifest.settings.map((s) => [s.key, s.default]));

const TOP_LIMIT = 8;
const MVP_LIMIT = 3;
const FEED_LIMIT = 6;
const JOIN_LIMIT = 20; // ekrandaki katılım duyuruları için son katılanlar
const CARD_MS = 4000; // 'takım' yazana gösterilen kartın süresi
const IDLE_PRUNE_MS = 10 * 60 * 1000; // yeni turda puansız ve 10 dk sessiz oyuncular bellekten atılır

// Türkçe küçültme + ı→i eşlemesi ("TAKIM" ve "takim" aynı olur).
const fold = (text) => String(text ?? '').toLocaleLowerCase('tr').replaceAll('ı', 'i');
const tokenize = (text) => fold(text).split(/[^\p{L}\p{N}]+/u).filter(Boolean);
const TEAM_QUERY = new Set(['takim', 'takimim', 'takimin', 'takimimi']);

function resolveSettings(input = {}) {
  const out = { ...DEFAULTS };
  for (const [key, def] of Object.entries(DEFAULTS)) {
    const v = input[key];
    if (v === undefined || v === null || v === '') continue;
    if (typeof def === 'number') {
      const n = Number(v);
      if (Number.isFinite(n)) out[key] = n;
    } else if (typeof def === 'boolean') {
      out[key] = typeof v === 'boolean' ? v : String(v) !== 'false';
    } else {
      out[key] = String(v);
    }
  }
  return out;
}

const teamName = (team) => (team === 'blue' ? 'Mavi' : 'Kırmızı');
const teamEmoji = (team) => (team === 'blue' ? '🔵' : '🔴');

export function create(settings, { now = Date.now, random = Math.random } = {}) {
  const cfg = resolveSettings(settings);
  let lastAssigned = null; // eşitlikte sıradaki takımı belirlemek için
  const joins = []; // { seq, nickname, avatarUrl, team }
  let joinSeq = 0;
  let teamCard = null; // { seq, nickname, avatarUrl, team, points, until }
  let cardSeq = 0;

  const players = new Map(); // id → { team, nickname, avatarUrl, roundPoints, lastCommentAt }
  let scores;
  let feed;
  let feedSeq = 0;
  const giftSeq = new Map(); // userId+giftId → kaç seri başlatıldı (kimlik çakışmasın diye)
  const openStreaks = new Map(); // userId+giftId → devam eden serinin feed kimliği
  let phase;
  let roundEnd;
  let overtimeEnd;
  let resultEnd;
  let result;
  let lastTickMs = -Infinity;
  const counts = { blue: 0, red: 0 }; // takım üye sayıları (artımlı tutulur)
  let topCache = null; // { blue, red }; null = yeniden hesaplanmalı

  function setTeam(p, team) {
    if (p.team === team) return;
    if (p.team) counts[p.team]--;
    p.team = team;
    if (team) counts[team]++;
    topCache = null;
  }

  function startRound(at) {
    scores = { blue: 0, red: 0 };
    feed = [];
    openStreaks.clear();
    for (const [id, p] of players) {
      if (p.roundPoints === 0 && at - p.lastSeenAt > IDLE_PRUNE_MS) {
        setTeam(p, null);
        players.delete(id);
        continue;
      }
      p.roundPoints = 0;
      p.lastCommentAt = -Infinity;
    }
    topCache = null;
    phase = 'playing';
    roundEnd = at + cfg.roundSec * 1000;
    overtimeEnd = null;
    resultEnd = null;
    result = null;
  }

  const teamCount = (team) => counts[team];

  // Tek geçişte, sınırlı eklemeli liste; eşitlikte katılma sırası korunur.
  function topsOf(limit) {
    const out = { blue: [], red: [] };
    for (const [id, p] of players) {
      if (!p.team) continue;
      const list = out[p.team];
      if (list.length === limit && p.roundPoints <= list[limit - 1].points) continue;
      let i = list.length;
      while (i > 0 && list[i - 1].points < p.roundPoints) i--;
      list.splice(i, 0, { id, nickname: p.nickname, avatarUrl: p.avatarUrl, points: p.roundPoints });
      if (list.length > limit) list.pop();
    }
    return out;
  }
  const topOf = (team, limit) => topsOf(limit)[team];

  function pushFeed(text, team) {
    const entry = { id: `f${++feedSeq}`, text, team };
    feed.push(entry);
    if (feed.length > FEED_LIMIT) feed.splice(0, feed.length - FEED_LIMIT);
    return entry;
  }

  function finish(winner, at) {
    phase = 'finished';
    resultEnd = at + cfg.resultSec * 1000;
    result = { winner, mvp: { blue: topOf('blue', MVP_LIMIT), red: topOf('red', MVP_LIMIT) } };
  }

  function judge(at) {
    if (scores.blue > scores.red) finish('blue', at);
    else if (scores.red > scores.blue) finish('red', at);
    else finish('draw', at);
  }

  function getPlayer(user) {
    let p = players.get(user.id);
    if (!p) {
      p = { team: null, nickname: user.nickname || user.uniqueId || user.id, avatarUrl: user.avatarUrl || '', roundPoints: 0, lastCommentAt: -Infinity, lastSeenAt: now() };
      players.set(user.id, p);
    } else {
      if (user.nickname && user.nickname !== p.nickname) {
        p.nickname = user.nickname;
        topCache = null;
      }
      if (user.avatarUrl && user.avatarUrl !== p.avatarUrl) {
        p.avatarUrl = user.avatarUrl;
        topCache = null;
      }
    }
    p.lastSeenAt = now();
    return p;
  }

  // İzleyici takım seçemez: her zaman sayısı az olan takıma girer; eşitse sıradaki takıma.
  function autoAssign(p) {
    const b = teamCount('blue');
    const r = teamCount('red');
    let team;
    if (b !== r) team = b < r ? 'blue' : 'red';
    else if (lastAssigned) team = lastAssigned === 'blue' ? 'red' : 'blue';
    else team = random() < 0.5 ? 'blue' : 'red';
    setTeam(p, team);
    lastAssigned = team;
    pushFeed(`${p.nickname} ${teamEmoji(team)} ${teamName(team)} takıma katıldı`, team);
    joins.push({ seq: ++joinSeq, nickname: p.nickname, avatarUrl: p.avatarUrl, team });
    if (joins.length > JOIN_LIMIT) joins.splice(0, joins.length - JOIN_LIMIT);
  }

  function award(p, points) {
    if (phase === 'finished' || !p.team || points <= 0) return;
    p.roundPoints += points;
    topCache = null;
    scores[p.team] += points;
  }

  function showTeamCard(p) {
    teamCard = { seq: ++cardSeq, nickname: p.nickname, avatarUrl: p.avatarUrl, team: p.team, points: p.roundPoints, until: now() + CARD_MS };
  }

  function onComment(p, evt) {
    if (!p.team) autoAssign(p);
    const asksTeam = tokenize(evt.comment).some((t) => TEAM_QUERY.has(t));
    if (phase !== 'finished') {
      const at = now();
      if (at - p.lastCommentAt >= cfg.commentCooldownSec * 1000) {
        p.lastCommentAt = at;
        award(p, cfg.commentPoints);
      }
    }
    if (asksTeam) showTeamCard(p);
  }

  function onGift(p, evt) {
    const g = evt.gift;
    if (!g) return;
    const key = `${evt.user.id}|${g.id}`;
    if (!g.final) {
      if (phase === 'finished') return;
      const text = `${p.nickname} · ${g.name} x${g.count} 🔥`;
      const open = openStreaks.get(key);
      const existing = open && feed.find((f) => f.id === open);
      if (existing) {
        existing.text = text;
        existing.team = p.team;
      } else {
        const n = giftSeq.get(key) ?? 0;
        giftSeq.set(key, n + 1);
        const id = `gift-${evt.user.id}-${g.id}${n ? `#${n}` : ''}`;
        openStreaks.set(key, id);
        feed.push({ id, text, team: p.team });
        if (feed.length > FEED_LIMIT) feed.splice(0, feed.length - FEED_LIMIT);
      }
      return;
    }
    if (phase === 'finished') return;
    if (!p.team) autoAssign(p);
    const points = g.diamonds * g.count * cfg.diamondPoints;
    const text = `${p.nickname} · ${g.name} x${g.count} · +${points}`;
    const open = openStreaks.get(key);
    const existing = open && feed.find((f) => f.id === open);
    openStreaks.delete(key);
    if (existing) {
      existing.text = text;
      existing.team = p.team;
    } else {
      pushFeed(text, p.team);
    }
    award(p, points);
  }

  function onEvent(evt) {
    if (!evt || !evt.user || !evt.user.id) return;
    const p = getPlayer(evt.user);
    switch (evt.type) {
      case 'join':
        if (cfg.autoAssignOnJoin && !p.team && phase !== 'finished') autoAssign(p);
        return;
      case 'comment':
        onComment(p, evt);
        return;
      case 'like':
      case 'follow':
      case 'share':
      case 'gift':
        break;
      default:
        return;
    }
    if (phase === 'finished') return; // bitmiş turda takımsızlar atanmaz, puan yazılmaz
    if (evt.type === 'gift') {
      onGift(p, evt);
      return;
    }
    if (!p.team) autoAssign(p);
    if (evt.type === 'like') {
      award(p, Math.max(0, Number(evt.likeCount) || 0) * cfg.likePoints);
    } else if (evt.type === 'follow') {
      award(p, cfg.followPoints);
      pushFeed(`${p.nickname} · takip etti · +${cfg.followPoints}`, p.team);
    } else {
      award(p, cfg.sharePoints);
      pushFeed(`${p.nickname} · paylaştı · +${cfg.sharePoints}`, p.team);
    }
  }

  function tick(nowMs) {
    lastTickMs = Math.max(lastTickMs, nowMs);
    for (let guard = 0; guard < 4; guard++) {
      if (phase === 'playing' && nowMs >= roundEnd) {
        // Kimse oynamadıysa uzatma/berabere ekranı göstermeden yeni tur başlar.
        if (counts.blue + counts.red === 0) startRound(roundEnd);
        else if (scores.blue !== scores.red) judge(roundEnd);
        else if (cfg.overtimeSec > 0) {
          phase = 'overtime';
          overtimeEnd = roundEnd + cfg.overtimeSec * 1000;
        } else judge(roundEnd);
      } else if (phase === 'overtime' && nowMs >= overtimeEnd) {
        judge(overtimeEnd);
      } else if (phase === 'finished' && nowMs >= resultEnd) {
        startRound(nowMs);
      } else {
        return;
      }
    }
  }

  function getState() {
    const at = Math.max(now(), lastTickMs);
    const end = phase === 'playing' ? roundEnd : phase === 'overtime' ? overtimeEnd : resultEnd;
    const rope = Math.max(-1, Math.min(1, (scores.red - scores.blue) / cfg.winDiff)); // negatif = mavi önde
    topCache ??= topsOf(TOP_LIMIT);
    return {
      phase,
      timeLeftMs: Math.max(0, end - at),
      scores: { ...scores },
      rope,
      teams: {
        blue: { count: teamCount('blue'), top: topCache.blue.map((t) => ({ ...t })) },
        red: { count: teamCount('red'), top: topCache.red.map((t) => ({ ...t })) },
      },
      feed: feed.map((f) => ({ ...f })),
      joins: joins.map((j) => ({ ...j })),
      rules: {
        likePoints: cfg.likePoints,
        commentPoints: cfg.commentPoints,
        diamondPoints: cfg.diamondPoints,
        followPoints: cfg.followPoints,
        sharePoints: cfg.sharePoints,
      },
      teamCard: teamCard && at < teamCard.until
        ? { seq: teamCard.seq, nickname: teamCard.nickname, avatarUrl: teamCard.avatarUrl, team: teamCard.team, points: teamCard.points }
        : null,
      result: result ? { winner: result.winner, mvp: { blue: [...result.mvp.blue], red: [...result.mvp.red] } } : null,
    };
  }

  startRound(now());
  return { onEvent, tick, getState, reset: () => startRound(now()) };
}
