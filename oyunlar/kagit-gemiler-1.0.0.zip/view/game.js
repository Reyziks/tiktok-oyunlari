// Kağıt Gemiler görünümü: durumu WebSocket'ten alır ve çizer; oyun mantığı ana süreçtedir.
import { connectState } from '/common/client.js';
import { fitStage } from '/common/stage.js';
import { startNarrator } from '/common/narrator.js';

const GAME_ID = 'kagit-gemiler';
const COLORS = ['#7c4dff', '#ff8f00', '#00a884', '#e84393', '#1e88e5', '#d63031', '#8e44ad', '#00acc1', '#f39c12', '#e17055', '#2ecc71', '#fd79a8'];
// Bitiş üstte: altta TikTok yorumları ekranı kapatır. Gemiler alttan yukarı akar.
const START_Y = 1400; // start çizgisindeki geminin üst kenarı (sahne y)
const FINISH_Y = 490; // bitişe varan geminin üst kenarı
const SIDE_X = { left: [150, 470], right: [490, 810] }; // geminin sol kenarı için x aralığı

const $ = (id) => document.getElementById(id);
const stage = $('stage');
const el = {
  boats: $('boats'), status: $('status'), leaders: $('leaders'),
  queue: $('queue'), queueList: $('queue-list'), queueMore: $('queue-more'),
  lobby: $('lobby'), lobbySub: $('lobby-sub'), lobbyGrid: $('lobby-grid'),
  podium: $('podium'), podiumRow: $('podium-row'),
  fork: $('fork'), armLeft: $('arm-left'), armRight: $('arm-right'), forkBanner: $('fork-banner'),
  howto: $('howto-main'), idle: $('idle'), idleText: $('idle-text'),
};
const narrator = startNarrator();

// ---------- yardımcılar ----------
const setText = (node, t) => { const s = String(t); if (node.textContent !== s) node.textContent = s; };
const hash = (s) => { let h = 0; for (const ch of String(s)) h = (Math.imul(h, 31) + ch.codePointAt(0)) | 0; return Math.abs(h); };
const secs = (ms) => Math.ceil(ms / 1000);
const seg = typeof Intl.Segmenter === 'function' ? new Intl.Segmenter('tr', { granularity: 'grapheme' }) : null;
function initialOf(name) {
  const s = String(name ?? '').trim();
  if (!s) return '?';
  return (seg ? seg.segment(s)[Symbol.iterator]().next().value.segment : Array.from(s)[0]).toLocaleUpperCase('tr');
}
const failed = new Set();
function setAvatar(node, p) {
  const key = `${p.avatarUrl}|${p.nickname}`;
  if (node.dataset.key === key) return;
  node.dataset.key = key;
  node.style.setProperty('--av-bg', COLORS[hash(p.id) % COLORS.length]);
  const initial = () => { node.replaceChildren(); node.textContent = initialOf(p.nickname); };
  if (!p.avatarUrl || failed.has(p.avatarUrl)) return initial();
  const img = document.createElement('img');
  img.alt = '';
  img.referrerPolicy = 'no-referrer';
  img.addEventListener('error', () => { failed.add(p.avatarUrl); if (img.parentNode === node) initial(); });
  img.src = p.avatarUrl;
  node.replaceChildren(img);
}
function avatarCard(p, cls) {
  const box = document.createElement('div');
  box.className = cls;
  box.innerHTML = '<div class="avatar"></div><div class="nm"></div>';
  setAvatar(box.firstChild, p);
  box.lastChild.textContent = p.nickname;
  return box;
}

// ---------- gemiler ----------
const nodes = new Map(); // seat → { root, avatar, name, bubble, id, bubbleSeq }

function boatNode(seat) {
  let n = nodes.get(seat);
  if (n) return n;
  const root = document.createElement('div');
  root.className = 'boat';
  root.innerHTML = '<div class="hull"><div class="sail"></div><div class="avatar"></div></div><div class="name"></div>';
  const bubble = document.createElement('div');
  bubble.className = 'bubble hidden';
  root.prepend(bubble);
  el.boats.append(root);
  n = { root, avatar: root.querySelector('.avatar'), name: root.querySelector('.name'), bubble, id: null, bubbleSeq: 0 };
  nodes.set(seat, n);
  return n;
}

function renderBoats(s) {
  const seen = new Set();
  const leaderId = s.leaders[0]?.progress > 0 ? s.leaders[0].id : null;
  for (const b of s.boats) {
    seen.add(b.seat);
    const n = boatNode(b.seat);
    const [x0, x1] = SIDE_X[b.side] || SIDE_X.left;
    const x = x0 + ((hash(`s${b.seat}`) % 100) / 100) * (x1 - x0);
    const y = START_Y - Math.min(1, b.progress / s.riverLength) * (START_Y - FINISH_Y) + (hash(`r${b.seat}`) % 4) * 28; // başta üst üste binmesinler diye hafif kademeli
    n.root.style.transform = `translate(${x}px, ${y}px)`;
    n.root.style.zIndex = String(100 + Math.round(y / 10));
    n.root.classList.toggle('spinning', b.spinning);
    n.root.classList.toggle('windy', b.windy);
    n.root.classList.toggle('leader', b.id === leaderId);
    if (n.id !== b.id) { n.id = b.id; setText(n.name, b.nickname); }
    setAvatar(n.avatar, b);
    if (b.bubble) {
      if (n.bubbleSeq !== b.bubbleSeq) { n.bubbleSeq = b.bubbleSeq; setText(n.bubble, b.bubble); }
      n.bubble.classList.remove('hidden');
    } else {
      n.bubble.classList.add('hidden');
    }
  }
  for (const [seat, n] of nodes) {
    if (!seen.has(seat)) { n.root.remove(); nodes.delete(seat); }
  }
}

let lastSwapSeq = null;
function renderSwaps(swaps) {
  const top = swaps.reduce((m, x) => Math.max(m, x.seq), 0);
  if (lastSwapSeq === null) { lastSwapSeq = top; return; }
  if (top < lastSwapSeq) lastSwapSeq = 0; // oyun yeniden başladı
  for (const x of swaps) {
    if (x.seq <= lastSwapSeq) continue;
    const n = nodes.get(x.seat);
    if (n) {
      n.root.classList.remove('swap');
      void n.root.offsetWidth; // animasyonu yeniden başlat
      n.root.classList.add('swap');
    }
  }
  lastSwapSeq = Math.max(lastSwapSeq, top);
}

// ---------- çatal ----------
function renderFork(fork) {
  el.fork.classList.toggle('hidden', !fork);
  el.forkBanner.classList.toggle('hidden', !fork);
  if (!fork) return;
  el.fork.classList.toggle('choosing', fork.choosing);
  el.armLeft.classList.toggle('shortcut', fork.shortcut === 'left');
  el.armRight.classList.toggle('shortcut', fork.shortcut === 'right');
  el.armLeft.classList.toggle('whirl', fork.shortcut === 'right');
  el.armRight.classList.toggle('whirl', fork.shortcut === 'left');
  setText(el.armLeft.firstChild, fork.shortcut ? (fork.shortcut === 'left' ? '⚡ KISA YOL' : '🌀 GİRDAP') : 'SOL');
  setText(el.armRight.firstChild, fork.shortcut ? (fork.shortcut === 'right' ? '⚡ KISA YOL' : '🌀 GİRDAP') : 'SAĞ');
  setText(el.forkBanner, fork.choosing ? `Çatal! Yoruma SAĞ ya da SOL yaz · ${secs(fork.leftMs)}` : 'Sis dağıldı!');
}

// ---------- paneller ----------
let lobbyKey = '';
function renderLobby(s) {
  el.lobby.classList.toggle('hidden', s.phase !== 'lobby');
  if (s.phase !== 'lobby') return;
  setText(el.lobbySub, s.lobby.length ? `${s.lobby.length} gemi hazır · Beğen, yorum yap, hediye at: en çok puan toplayanlar yarışır!` : 'Yarışa girmek için beğen ya da yorum yap!');
  const key = s.lobby.map((p) => `${p.id}|${p.avatarUrl}`).join(',');
  if (key === lobbyKey) return;
  lobbyKey = key;
  el.lobbyGrid.replaceChildren(...s.lobby.map((p) => avatarCard(p, 'slot')));
}

let podiumKey = '';
function renderPodium(s) {
  el.podium.classList.toggle('hidden', !s.podium);
  if (!s.podium) { podiumKey = ''; return; }
  const key = s.podium.map((p) => p.id).join(',');
  if (key === podiumKey) return;
  podiumKey = key;
  const order = [s.podium[1], s.podium[0], s.podium[2]].filter(Boolean); // 2-1-3 dizilişi
  el.podiumRow.replaceChildren(...order.map((p) => avatarCard(p, `place${p === s.podium[0] ? ' first' : ''}`)));
}

function renderTop(s) {
  const left = secs(s.phaseLeftMs);
  setText(el.status, s.phase === 'lobby' ? `Yarış ${left} sn sonra başlıyor` : s.phase === 'race' ? `⏱ ${left} sn · ${s.boats.length} gemi` : 'Yarış bitti!');
  const key = s.leaders.map((l) => `${l.id}:${Math.round(l.progress)}`).join(',');
  if (el.leaders.dataset.key !== key) {
    el.leaders.dataset.key = key;
    el.leaders.replaceChildren(...(s.phase === 'race' ? s.leaders : []).map((l, i) => {
      const li = document.createElement('li');
      li.textContent = `${i + 1}. ${l.nickname} · %${Math.round((l.progress / s.riverLength) * 100)}`;
      return li;
    }));
  }
  el.queue.classList.toggle('hidden', s.phase !== 'race' || s.queue.length === 0);
  const qkey = s.queue.map((p) => `${p.id}:${p.score}`).join(',');
  if (el.queueList.dataset.key !== qkey) {
    el.queueList.dataset.key = qkey;
    el.queueList.replaceChildren(...s.queue.map((p) => {
      const li = document.createElement('li');
      li.innerHTML = '<span></span><span></span>';
      li.firstChild.textContent = p.nickname;
      li.lastChild.textContent = p.score.toLocaleString('tr-TR');
      return li;
    }));
  }
  setText(el.queueMore, s.waiting > s.queue.length ? `+${s.waiting - s.queue.length}` : '');
}

function render(s) {
  renderTop(s);
  renderBoats(s);
  renderSwaps(s.swaps);
  renderFork(s.phase === 'race' ? s.fork : null);
  renderLobby(s);
  renderPodium(s);
  narrator.handle(s);
}

// ---------- dönen ipuçları ----------
const TIPS = ['Beğen → kürek · Hediye → rüzgâr · Çatalda SAĞ/SOL yaz', '🔀 Çatalda bir kol kısa yol, öteki girdap!', '🔮 Yarışta değilsen de tahmin et: bilirsen öne geçersin', '💤 Sessiz kalan gemisini sıradakine bırakır'];
let tip = 0;
setInterval(() => {
  el.howto.classList.add('fade');
  setTimeout(() => { setText(el.howto, TIPS[++tip % TIPS.length]); el.howto.classList.remove('fade'); }, 350);
}, 4500);

function onMessage(msg) {
  if (msg?.type === 'state' && msg.gameId === GAME_ID && msg.state) {
    el.idle.classList.add('hidden');
    render(msg.state);
  } else if (msg?.type === 'idle' || msg?.type === 'state') {
    setText(el.idleText, 'Oyun başlatılmadı');
    el.idle.classList.remove('hidden');
  }
}

fitStage(stage);
connectState(onMessage);
