// Kağıt Gemiler oyun mantığı: en çok etkileşim yapanlar derede yarışır; çatallarda SAĞ/SOL seçilir.
// Saf ESM modül: saat ve rastgelelik dışarıdan verilir.
import { readFileSync } from 'node:fs';

const manifest = JSON.parse(readFileSync(new URL('./manifest.json', import.meta.url), 'utf8'));
const DEFAULTS = Object.fromEntries(manifest.settings.map((s) => [s.key, s.default]));

const BUBBLE_MAX = 60;
const WIND_MS = 3000; // hediye rüzgârı bu sürede yayılır
const FORK_SHOW_MS = 3000; // çatal sonucu ekranda kalma süresi
const LEAD_QUIET_MS = 5000; // yarışın ilk 5 sn'sinde lider değişimi duyurulmaz
const NO_SWAP_FROM = 0.8; // derenin son %20'sinde gemi el değiştirmez
const BIG_GIFT = 99;
const QUEUE_SHOWN = 5;
const SWAPS_KEPT = 8;
const VOICES_KEPT = 4;
const PEOPLE_MAX = 5000;

function resolveSettings(input = {}) {
  const out = { ...DEFAULTS };
  for (const [key, def] of Object.entries(DEFAULTS)) {
    const v = input[key];
    if (v === undefined || v === null || v === '') continue;
    if (typeof def === 'number') {
      const n = Number(v);
      if (Number.isFinite(n)) out[key] = n;
    } else if (typeof def === 'boolean') {
      out[key] = typeof v === 'boolean' ? v : String(v) !== 'false';
    } else {
      out[key] = String(v);
    }
  }
  return out;
}

// Yorumun ilk kelimesi 'sağ'/'sağa' ya da 'sol'/'sola' mı? Büyük-küçük harf ve noktalama önemsiz.
export function parseSide(text) {
  const words = String(text ?? '').trim().split(/\s+/).map((w) => w.toLocaleLowerCase('tr').replace(/ğ/g, 'g').replace(/[^\p{L}\p{N}]/gu, ''));
  const word = words.find((w) => /\p{L}/u.test(w)) || ''; // emojiyle başlayan yorumlarda ilk gerçek kelime
  if (word === 'sag' || word === 'saga') return 'right';
  if (word === 'sol' || word === 'sola') return 'left';
  return null;
}

export function create(settings, { now = Date.now, random = Math.random } = {}) {
  const cfg = resolveSettings(settings);
  const people = new Map(); // id → { id, nickname, avatarUrl, score, lastActiveAt, bubble, bubbleSeq, bubbleUntil }
  let seq = 0;
  let phase = 'lobby';
  let phaseEnd = now() + cfg.lobbySec * 1000;
  let boats = []; // [{ seat, id, progress, side, spinUntil, gusts: [{ amount, start, applied }] }]
  let fork = null; // { seq, choosing, endsAt, shortcut, showUntil }
  let guesses = new Map(); // seyirci id → 'left' | 'right'
  let nextForkAt = 0;
  let podium = null;
  let swaps = [];
  let voices = [];
  let leaderId = null;
  let leadQuietUntil = 0;
  let finalSaid = false;
  let lastTickAt = now();

  const cue = (name) => {
    voices.push({ seq: ++seq, cue: name });
    if (voices.length > VOICES_KEPT) voices = voices.slice(-VOICES_KEPT);
  };
  const isAfk = (p, t) => p.lastActiveAt <= t - cfg.afkSec * 1000;
  const boatOf = (id) => boats.find((b) => b.id === id);
  const byScore = (a, b) => b.score - a.score || b.lastActiveAt - a.lastActiveAt;
  const waitingList = (t) => {
    const onBoard = new Set(boats.map((b) => b.id));
    return [...people.values()].filter((p) => !onBoard.has(p.id) && !isAfk(p, t)).sort(byScore);
  };
  const spinning = (b, t) => t < b.spinUntil;

  function personOf(user) {
    let p = people.get(user.id);
    if (!p) {
      p = { id: user.id, nickname: user.nickname || user.uniqueId || user.id, avatarUrl: user.avatarUrl || '', score: 0, lastActiveAt: now(), bubble: null, bubbleSeq: 0, bubbleUntil: 0 };
      people.set(user.id, p);
    } else {
      if (user.nickname) p.nickname = user.nickname;
      if (user.avatarUrl) p.avatarUrl = user.avatarUrl;
    }
    p.lastActiveAt = now();
    return p;
  }

  function startLobby(t) {
    phase = 'lobby';
    phaseEnd = t + cfg.lobbySec * 1000;
    for (const p of people.values()) p.score = 0;
    boats = [];
    fork = null;
    guesses = new Map();
    podium = null;
    cue('lobby');
  }

  function startRace(t, racers) {
    phase = 'race';
    phaseEnd = t + cfg.raceSec * 1000;
    boats = racers.map((p, seat) => ({ seat, id: p.id, progress: 0, side: random() < 0.5 ? 'left' : 'right', spinUntil: 0, gusts: [] }));
    nextForkAt = t + cfg.forkEverySec * 1000;
    fork = null;
    leaderId = null;
    leadQuietUntil = t + LEAD_QUIET_MS;
    finalSaid = false;
    swaps = [];
    cue('race_start');
  }

  function finish(t) {
    phase = 'podium';
    phaseEnd = t + cfg.podiumSec * 1000;
    fork = null; // açık çatal iptal
    podium = [...boats].sort((a, b) => b.progress - a.progress).slice(0, 3).map((b) => {
      const p = people.get(b.id);
      return { id: b.id, nickname: p.nickname, avatarUrl: p.avatarUrl, progress: b.progress };
    });
    cue('winner');
  }

  function move(b, n) {
    b.progress = Math.min(cfg.riverLength, b.progress + n);
  }

  function onEvent(evt) {
    if (!evt || !evt.user || !evt.user.id) return;
    const p = personOf(evt.user);
    const t = now();
    const b = phase === 'race' ? boatOf(p.id) : null;
    switch (evt.type) {
      case 'like': {
        const n = Math.max(0, Number(evt.likeCount) || 0) * cfg.likePower;
        p.score += n;
        if (b && !spinning(b, t)) move(b, n);
        break;
      }
      case 'comment': {
        const raw = String(evt.comment ?? '');
        const side = parseSide(raw);
        if (side && phase === 'race' && fork?.choosing) {
          if (b) b.side = side;
          else guesses.set(p.id, side);
        }
        const text = raw.trim().slice(0, BUBBLE_MAX);
        if (text) {
          p.bubble = text;
          p.bubbleSeq = ++seq;
          p.bubbleUntil = t + cfg.bubbleSec * 1000;
        }
        p.score += cfg.commentPoints;
        break;
      }
      case 'gift': {
        const g = evt.gift;
        if (!g || !g.final) break; // seri hediye: puan seri bitince
        const diamonds = Math.max(0, Number(g.diamonds) || 0) * Math.max(1, Number(g.count) || 1);
        const n = diamonds * cfg.diamondPower;
        p.score += n;
        if (diamonds >= BIG_GIFT) cue('big_gift');
        if (b && n > 0) b.gusts.push({ amount: n, start: t, applied: 0 });
        break;
      }
      case 'follow':
        p.score += cfg.followPoints;
        break;
      case 'share':
        p.score += cfg.sharePoints;
        break;
      default:
        break;
    }
  }

  function blowWind(t, dt) {
    for (const b of boats) {
      if (spinning(b, t)) {
        for (const g of b.gusts) g.start += dt; // girdapta rüzgâr bekler
        continue;
      }
      for (const g of b.gusts) {
        const due = g.amount * Math.min(1, (t - g.start) / WIND_MS);
        move(b, due - g.applied);
        g.applied = due;
      }
      b.gusts = b.gusts.filter((g) => g.applied < g.amount);
    }
  }

  function runFork(t) {
    if (fork && !fork.choosing && t >= fork.showUntil) fork = null;
    if (!fork && t >= nextForkAt) {
      fork = { seq: ++seq, choosing: true, endsAt: t + cfg.forkChoiceSec * 1000, shortcut: null, showUntil: 0 };
      guesses = new Map();
      cue('fork_coming');
    } else if (fork?.choosing && t >= fork.endsAt) {
      const shortcut = random() < 0.5 ? 'left' : 'right';
      let lucky = 0;
      for (const b of boats) {
        if (b.side === shortcut) {
          move(b, cfg.shortcutBoost);
          lucky++;
        } else {
          b.spinUntil = t + cfg.whirlpoolSec * 1000;
        }
      }
      for (const [id, side] of guesses) {
        const p = people.get(id);
        if (p && side === shortcut && !boatOf(id)) p.score += cfg.guessBonus;
      }
      guesses = new Map();
      if (lucky >= boats.length - lucky) cue('fork_shortcut');
      else cue('fork_whirlpool');
      fork = { ...fork, choosing: false, shortcut, showUntil: t + FORK_SHOW_MS };
      nextForkAt = t + cfg.forkEverySec * 1000;
    }
  }

  // AFK yarışçının gemisini sıradaki en yüksek puanlı devralır (aynı yer, aynı ilerleme).
  function fillSeats(t) {
    let waiting = null; // yalnızca AFK gemi varsa, bir kez hesaplanır
    let swapped = false;
    for (const b of boats) {
      const p = people.get(b.id);
      if (p && !isAfk(p, t)) continue;
      if (b.progress >= NO_SWAP_FROM * cfg.riverLength) continue;
      waiting ??= waitingList(t);
      const next = waiting.shift();
      if (!next) break; // yedek yoksa gemiler kalır
      swaps.push({ seq: ++seq, seat: b.seat, outId: b.id, inId: next.id });
      if (swaps.length > SWAPS_KEPT) swaps = swaps.slice(-SWAPS_KEPT);
      b.id = next.id;
      swapped = true;
    }
    if (swapped) cue('swap'); // aynı tickte tek duyuru: diğer işaretleri listeden düşürmesin
  }

  function announceLeader(t) {
    const top = boats.reduce((m, b) => (!m || b.progress > m.progress ? b : m), null);
    if (!top || top.progress <= 0) return;
    if (top.id !== leaderId) {
      if (leaderId !== null && t >= leadQuietUntil) cue('lead_change');
      leaderId = top.id;
    }
    if (!finalSaid && top.progress >= NO_SWAP_FROM * cfg.riverLength) {
      finalSaid = true;
      cue('final_stretch');
    }
  }

  function prune(t) {
    if (people.size <= PEOPLE_MAX) return;
    const idle = [...people.values()].filter((p) => !boatOf(p.id) && isAfk(p, t)).sort((a, b) => a.score - b.score);
    for (const p of idle.slice(0, people.size - PEOPLE_MAX)) people.delete(p.id);
  }

  function tick(t) {
    const dt = Math.max(0, t - lastTickAt);
    lastTickAt = t;
    if (phase === 'lobby') {
      if (t >= phaseEnd) {
        const racers = waitingList(t).slice(0, cfg.maxRacers);
        if (racers.length) startRace(t, racers);
        else phaseEnd = t + cfg.lobbySec * 1000; // kimse yoksa lobi bekler
      }
    } else if (phase === 'race') {
      blowWind(t, dt);
      runFork(t);
      fillSeats(t);
      if (boats.some((b) => b.progress >= cfg.riverLength) || t >= phaseEnd) finish(t);
      else announceLeader(t);
    } else if (phase === 'podium' && t >= phaseEnd) {
      startLobby(t);
    }
    prune(t);
  }

  const card = (p) => ({ id: p.id, nickname: p.nickname, avatarUrl: p.avatarUrl, score: p.score });

  function getState() {
    const t = now();
    const waiting = phase === 'lobby' ? [] : waitingList(t);
    const leaders = [...boats].sort((a, b) => b.progress - a.progress).slice(0, 3);
    return {
      phase,
      phaseLeftMs: Math.max(0, phaseEnd - t),
      riverLength: cfg.riverLength,
      lobby: phase === 'lobby' ? waitingList(t).slice(0, cfg.maxRacers).map(card) : [],
      boats: boats.map((b) => {
        const p = people.get(b.id);
        return {
          seat: b.seat,
          id: b.id,
          nickname: p.nickname,
          avatarUrl: p.avatarUrl,
          progress: b.progress,
          side: b.side,
          spinning: spinning(b, t),
          windy: b.gusts.length > 0,
          bubble: t < p.bubbleUntil ? p.bubble : null,
          bubbleSeq: p.bubbleSeq,
        };
      }),
      queue: waiting.slice(0, QUEUE_SHOWN).map(card),
      waiting: waiting.length,
      leaders: leaders.map((b) => ({ id: b.id, nickname: people.get(b.id).nickname, progress: b.progress })),
      fork: fork ? { seq: fork.seq, choosing: fork.choosing, leftMs: fork.choosing ? Math.max(0, fork.endsAt - t) : 0, shortcut: fork.shortcut } : null,
      podium: podium ? podium.map((x) => ({ ...x })) : null,
      swaps: swaps.map((x) => ({ ...x })),
      voices: cfg.voiceEnabled ? voices.map((v) => ({ ...v })) : [],
    };
  }

  function reset() {
    startLobby(now());
    voices = [];
    swaps = [];
  }

  return { onEvent, tick, getState, reset };
}
